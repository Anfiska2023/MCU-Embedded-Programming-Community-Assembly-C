﻿

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using PCComm;
using System.Text.RegularExpressions;
using System.Threading.Tasks;  // en haut du fichier
using System.IO;
using System.Text;

namespace PCComm
{
    public partial class frmMain : Form
    {
        private TaskCompletionSource<int> _tcsDur;
        private TaskCompletionSource<int> _tcsDim;
        // TCS pour synchroniser GETID(comme pour GETDUR/DIM)
        private TaskCompletionSource<int> _tcsId;
        private TaskCompletionSource<int> _tcsHi;
        private static string FormatId8(int id) => id.ToString("00000000");
        // en haut de frmMain
        private TaskCompletionSource<bool> _tcsInfo;

        CommunicationManager comm = new CommunicationManager();
        string transType = string.Empty;
        List<string> cmdData = new List<string>();
        public frmMain()
        {
            InitializeComponent();

           
            comm.DisplayWindow = rtbDisplay;
            // (facultatif mais conseillé)
            comm.CurrentTransmissionType = CommunicationManager.TransmissionType.Text;
            // évite doublons puis abonne
            comm.LineReceived -= Comm_LineReceived;
            comm.LineReceived += Comm_LineReceived;
            this.txtSend.KeyPress += txtSend_KeyPress;
            // (optionnel) petit log pour vérifier que ça arrive bien
            void Comm_LineReceived_DebugTap(string s) => rtbDisplay.AppendText($"[RX-line] {s}\r\n");
            //comm.LineReceived += Comm_LineReceived_DebugTap;

            // si tu as un RadioButton Hex/Text, force Text avant un Read:
            rdoText.Checked = true;
            comm.CurrentTransmissionType = CommunicationManager.TransmissionType.Text;
        }

        void txtSend_KeyPress(object sender, KeyPressEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.KeyChar.Equals((char)13))
            {
                sendDataToPort();
            }
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            try
            {
                LoadValues();
                SetDefaults();
                SetControlState();
                ajoutation();
            }
            catch (Exception ex)
            {
                //MessageBox.Show("Failure occcured while loading!\n" +
                    //ex.Message);
            }
                    

        }

        private void ajoutation ()
        {
            cb_commande.BeginUpdate();
            cb_commande.Items.Clear();
            cmdData.Clear(); // important

            cb_commande.Items.Add("");
            cmdData.Add("");

            cb_commande.Items.Add("Infos courtes (bannière/version)");
            cmdData.Add("<,INFO,>");

            cb_commande.Items.Add("============================================================ \r\n");
            cmdData.Add("");
            if (cbxGG.Checked)
            {

            cb_commande.Items.Add("----------—General —----------------------------------------");
            cmdData.Add("");

                cb_commande.Items.Add("Aide pour les commande USART ");
                cmdData.Add("<,HELP,>");

                cb_commande.Items.Add("Sauvegarde numero ID 32-bit (8 chiffres) en EEPROM");
                cmdData.Add("<,SETID,NNNNNNNN,>");

                cb_commande.Items.Add("Lecture numero ID - 8 chiffres");
                cmdData.Add("<,GETID,>");

                cb_commande.Items.Add("Réinitialise EEPROM (ID non programmé)");
                cmdData.Add("<,EERESET,>");

                cb_commande.Items.Add("============================================================ \r\n");
            cmdData.Add("");
            }
            if (cbxMSS.Checked)
            {
            cb_commande.Items.Add("----------- Motion Sensor Programming ----------------------");
            cmdData.Add("");

                cb_commande.Items.Add("Durée hold en minutes (1..120), sauvegardée EEPROM");
                cmdData.Add("<,SETDUR,MM,>");

                cb_commande.Items.Add("Hight Mode Programming (1..100), sauvegardée EEPROM");
                cmdData.Add("<,SETHI,MM,>");

                cb_commande.Items.Add("Hight Mode Read (1..100), from EEPROM");
                cmdData.Add("<,GETHI,MM,>");

                cb_commande.Items.Add("Lecture duree hold in sec");
                cmdData.Add("<,GETDUR,>");

                cb_commande.Items.Add("Niveau mini en % (10..100), sauvegardé EEPROM");
                cmdData.Add("<,SETDIM,PP[,NOW],>");

                cb_commande.Items.Add("Lecture niveau mini");
                cmdData.Add("<,GETDIM,>");

                cb_commande.Items.Add("Ligne statut compacte Motion Sensor programming");
                cmdData.Add("<,PRINTCFGLN,>");

                cb_commande.Items.Add("Secondes restantes du hold (0 si inactif) pour Motion Sensor");
                cmdData.Add("<,GETREMAIN,>");

                cb_commande.Items.Add("Affiche le mode courant pour Motion Sensor");
                cmdData.Add("<,GETMOTION,>");

            cb_commande.Items.Add("============================================================ \r\n");
            cmdData.Add("");
            }

            if (cbxMS.Checked)
            {
            cb_commande.Items.Add("----------- SystemTick tests -------------------------------");
            cmdData.Add("");

                cb_commande.Items.Add("Heartbeat OFF (0) / ON (1)");
                cmdData.Add("<,HB,0|1,>");

                cb_commande.Items.Add("Mode rapide en idle OFF/ON (idle→200 ms si ON)");
                cmdData.Add("<,HBF,0|1,>");

                cb_commande.Items.Add("Période “normale” en ms (ex. 500)");
                cmdData.Add("<,HBPER,NNN,>");

                cb_commande.Items.Add("Période “rapide” en ms (ex. 200)");
                cmdData.Add("<,HBFAST,NNN,>");

                cb_commande.Items.Add("État heartbeat (enable, fast-mode, périodes)");
                cmdData.Add("<,GETHB,>");

                cb_commande.Items.Add("LED fixe ON/OFF ou retour au clignotement");
                cmdData.Add("<,LED,ON|OFF|BLINK,>");            

            cb_commande.Items.Add("============================================================ \r\n");
            cmdData.Add("");
            }
            if (checkBox1.Checked)
            {
            cb_commande.Items.Add("----------- Motion Sensor tests-----------------------------");
            cmdData.Add("");
                cb_commande.Items.Add("Simule un mouvement (arme le hold)");            
                cmdData.Add("<,TRIG,>");

                cb_commande.Items.Add("Force 100% et stoppe le hold");
                cmdData.Add("<,TRIGH,>");

                cb_commande.Items.Add("Force niveau mini sans armer le hold");
                cmdData.Add("<,TRIGL,>");

                cb_commande.Items.Add("Active/Désactive message UART “EXTI: Motion detected”");
                cmdData.Add("<,MSMSG,1|0,>");

                cb_commande.Items.Add("Debounce des messages (ms, ex. 600)");
                cmdData.Add("<,MSMSG,WIN,NNN,>");

                cb_commande.Items.Add("Debounce  interrupt EXTI (ms, ex. 600)");
                cmdData.Add("<,MOTION,REFRACT,NNN,>");

                cb_commande.Items.Add("============================================================ \r\n");
            cmdData.Add("");
            }
            if (cbxMSLC.Checked)
            {
            cb_commande.Items.Add("----------- Motion Sensor Logique change--------------------");
            cmdData.Add("");

                cb_commande.Items.Add("Mode INVERSE  (présence→min, fin hold→100%)");
                cmdData.Add("<,MOTION,MODE,INV[,SAVE],>");

                cb_commande.Items.Add("Mode NORMAL   (présence→100%, fin hold→min)");
                cmdData.Add("<,MOTION,MODE,NORM[,SAVE],>");

            cb_commande.Items.Add("============================================================ \r\n");
            cmdData.Add("");
            }
            if (cbxDACT.Checked)
            {
            cb_commande.Items.Add("----------- DAC tests---------------------------------------");
            cmdData.Add("");

                cb_commande.Items.Add("Applique un pourcentage 0..100% sur le DAC");
                cmdData.Add("<,DAC,PP,>");

                cb_commande.Items.Add("Séquence 25→50→75→100 % (période TT ms, défaut 300 ms)");
                cmdData.Add("<,DACTEST,TT,>");

            cb_commande.Items.Add("============================================================ \r\n");
            cmdData.Add("");
            }         
            cb_commande.SelectedIndex = 0;
            cb_commande.EndUpdate();
        }
        private async void cmdOpen_Click(object sender, EventArgs e)
        {
            try
            {
                // Prépare UI
                cmdOpen.Enabled = false;
                cmdClose.Enabled = false;
                cmdSend.Enabled = false;
                // Configure le manager
                comm.Parity = cboParity.Text;
                comm.StopBits = cboStop.Text;
                comm.DataBits = cboData.Text;
                comm.BaudRate = cboBaud.Text;
                comm.DisplayWindow = rtbDisplay;
                comm.PortName = cboPort.SelectedItem.ToString();
                comm.CurrentTransmissionType = CommunicationManager.TransmissionType.Text;
                if (string.IsNullOrWhiteSpace(comm.PortName))
                {
                    MessageBox.Show("Choisissez un port série.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cmdOpen.Enabled = true;
                    return;
                }

                // Ouvre physiquement
                if (!comm.OpenPort())
                {
                    MessageBox.Show("Impossible d’ouvrir le port.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    cmdOpen.Enabled = true;
                    return;
                }

                // Handshake: envoie <,INFO,> et attend "INFO: ..."
                _tcsInfo = new TaskCompletionSource<bool>();
               
                string TxText = "<,INFO,>";
                if (cbxCR.Checked) TxText += "\r";
                if (cbxLF.Checked) TxText += "\n";
               // comm.WriteData(TxText);
                var done = await Task.WhenAny(_tcsInfo.Task, Task.Delay(2000)); // 2 s timeout (ajuste si besoin)

               /* if (done != _tcsInfo.Task || !_tcsInfo.Task.Result)
                {
                    // Pas de réponse -> referme et alerte
                    comm.closePort();
                    MessageBox.Show("Aucune réponse INFO du MCU.\nPort fermé.\nVérifiez le câblage/alimentation/baud.",
                                    "MCU non détecté", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    cmdOpen.Enabled = true;
                    return;
                }*/

                // OK: activer l’UI normale
                cmdClose.Enabled = true;
                cmdSend.Enabled = true;
                groupBox4.Visible = true;
                comportset.BackColor = Color.DarkCyan;
                comportset.Enabled = false;
                // (optionnel) lancer une requête d’état initiale
                // comm.WriteData("<,PRINTCFGLN,>");

            }
            catch
            {
                try { comm.closePort(); } catch { }
                MessageBox.Show("Erreur à l’ouverture/handshake du port.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cmdOpen.Enabled = true;
            }
        }

       

        /// <summary>
        /// Method to initialize serial port
        /// values to standard defaults
        /// </summary>
        private void SetDefaults()
        {
            cboPort.SelectedIndex = 0;
            cboBaud.SelectedIndex = 5;
            cboParity.SelectedIndex = 0;
            cboStop.SelectedIndex = 1;
            cboData.SelectedIndex = 1;
        }

        /// <summary>
        /// methos to load our serial
        /// port option values
        /// </summary>
        private void LoadValues()
        {
            try {
                comm.SetPortNameValues(cboPort);
                comm.SetParityValues(cboParity);
                comm.SetStopBitValues(cboStop);
            }catch(Exception ex) { }
        }

        /// <summary>
        /// method to set the state of controls
        /// when the form first loads
        /// </summary>
        private void SetControlState()
        {
            rdoText.Checked = true;
            comm.CurrentTransmissionType = CommunicationManager.TransmissionType.Text; // important
            //comm.CurrentTransmissionType = CommunicationManager.TransmissionType.Text; // <<< ICI
            cmdSend.Enabled = false;
            cmdClose.Enabled = false;
            //numID.Value = 0;
            //numID_ValueChanged(null, EventArgs.Empty);

        }

        private void sendDataToPort()
        {
            try
            {
                string TxText = txtSend.Text;
                if (cbxCR.Checked) TxText += "\r";
                if (cbxLF.Checked) TxText += "\n";
                comm.WriteData(TxText);
            }
            catch (Exception ex)
            {
            }
        }

        private void cmdSend_Click(object sender, EventArgs e)
        {
            sendDataToPort();
        }

        private void rdoHex_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoHex.Checked == true)
            {
                comm.CurrentTransmissionType = PCComm.CommunicationManager.TransmissionType.Hex;
            }
            else
            {
                comm.CurrentTransmissionType = PCComm.CommunicationManager.TransmissionType.Text;
            }
        }

        void closeComPort()
        {
            try
            {
                comm.closePort();
                //cmdOpen.Enabled = true;
            }
            catch (Exception ex)
            {
                cmdOpen.Enabled = true;
            }
            finally
            {
                cmdOpen.Enabled = true;
            }
        }

        private void cmdClose_Click(object sender, EventArgs e)
        {
            closeComPort();
            cmdOpen.Enabled = true;
            cmdOpen.BackColor = Color.Black;
            cmdOpen.Text = ("Connect");
            cmdClose.Enabled = false;
            comportset.BackColor = Color.Black;
            groupBox4.Visible = false;
            comportset.Enabled = true; ;
        }

        private void zoomdec_Click(object sender, EventArgs e)
        {
            try
            {
                rtbDisplay.ZoomFactor = (rtbDisplay.ZoomFactor - (float)0.2);
            }
            catch (Exception ex) { }
        }

        public void onAppClosing()
        {
            try
            {
                comm.closePort();
            }
            catch (Exception ex) { }
        }
        private void ZoomInc_Click(object sender, EventArgs e)
        {
            try
            {
                rtbDisplay.ZoomFactor = (rtbDisplay.ZoomFactor + (float)0.2);
            }
            catch (Exception ex) { }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnMin_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.rtbDisplay.Clear();
           // comm.DiscardBuffers();   // si ajouté côté manager
        }

       

        private void rtbDisplay_TextChanged(object sender, EventArgs e)
        {
            //string t = Properties.Settings.Default.Commandes;

        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cb_commande_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_commande.SelectedIndex >= 0)
            {
                string payload = cmdData[cb_commande.SelectedIndex];
                txtSend.Text = payload;
                cmdSend.Enabled = !string.IsNullOrWhiteSpace(payload); // désactive si menu
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
                MessageBox.Show(
                      "MS-IR-EE Terminal Test program \r\n\r\n" +
                      "MSIREE - L0 — UART HELP(Code actuel) \r\n" +
                      "Firmware cible: STM32L0(Motion Sensor Board) \r\n" +
                      "Trame: <, CMD[, ARG1[, ARG2...]],> \r\n" +
                      "Retour : texte ASCII\r\n" +
                      "For use program:\r\n" +
                      "1. Connect device to PC, Set setting for COM port\r\n" +
                      "2. Click Open COM Port\r\n" +
                      "3. Choise setting for Affichage\r\n" +
                      "In Console window look for resultates\r\n" +
                      "If you need message predefined - choise in Commande predefini and click  send button\r\n" +
                      "=== INFOS GÉNÉRALES ===\r\n" +
                      "  - Détection mouvement via EXTI(MOTION_Pin)\r\n" +
                      "  - Dimming par DAC(ApplyBrightnessPercent)\r\n" +
                      "  - Minuteur de présence via RTC WakeUp(1 Hz, WUT = 0)\r\n" +
                      "  - Heartbeat LED via SysTick(500 ms / 200 ms)\r\n" +
                      "  - UART non bloquant en ISR(messages envoyés en boucle main)\r\n" +
                      "24-10-2025 ELUMEN", "Help",MessageBoxButtons.OK,MessageBoxIcon.Information

                  );
            

        }
        private void cbxMS_CheckedChanged(object sender, EventArgs e)
        {
            ajoutation();
        }

        private void cbxGG_CheckedChanged(object sender, EventArgs e)
        {
            ajoutation();
        }

        private void cbxMSS_CheckedChanged(object sender, EventArgs e)
        {
            ajoutation();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            ajoutation();
        }

        private void cbxMSLC_CheckedChanged(object sender, EventArgs e)
        {
            ajoutation();
        }

        private void cbxDACT_CheckedChanged(object sender, EventArgs e)
        {
            ajoutation();
        }
        private async void btxREAD_Click(object sender, EventArgs e)
        {
            btxREAD.Enabled = false;
            comm.CurrentTransmissionType = CommunicationManager.TransmissionType.Text;

            _tcsDur = new TaskCompletionSource<int>();
            comm.WriteData(BuildCmd("<,GETDUR,>"));
            var doneDur = await Task.WhenAny(_tcsDur.Task, Task.Delay(2000));
            if (doneDur != _tcsDur.Task) rtbDisplay.AppendText("[WARN] GETDUR timeout\r\n");

            _tcsHi = new TaskCompletionSource<int>();
            comm.WriteData(BuildCmd("<,GETHI,>"));
            var doneHi = await Task.WhenAny(_tcsHi.Task, Task.Delay(2000));
            if (doneHi != _tcsHi.Task) rtbDisplay.AppendText("[WARN] GETHI timeout\r\n");

            _tcsDim = new TaskCompletionSource<int>();
            comm.WriteData(BuildCmd("<,GETDIM,>"));
            var doneDim = await Task.WhenAny(_tcsDim.Task, Task.Delay(2000));
            if (doneDim != _tcsDim.Task) rtbDisplay.AppendText("[WARN] GETDIM timeout\r\n");

            _tcsId = new TaskCompletionSource<int>();
            comm.WriteData(BuildCmd("<,GETID,>"));
            var doneId = await Task.WhenAny(_tcsId.Task, Task.Delay(2000));
            if (doneId != _tcsId.Task) rtbDisplay.AppendText("[WARN] GETID timeout\r\n");

            btxREAD.Enabled = true;
        }


        private void Comm_LineReceived(string text)
        {
            // on reçoit ici “line” déjà trim par ton CommunicationManager
            string line = text;
            // Réponse d'INFO (ex: "INFO: STM32L0 Ver1.0")
            if (System.Text.RegularExpressions.Regex.IsMatch(text, @"(?i)^INFO\b"))
            {
                _tcsInfo?.TrySetResult(true);  // réveille le handshake
                                               // tu peux aussi logger ici si tu veux
                                               // rtbDisplay.AppendText("[Handshake OK]\r\n");
                                               // pas de return obligatoire; on peut laisser parser le reste
            }

            // --- DUR=5 min ---
            var mDur = Regex.Match(line, @"DUR\s*=\s*(\d{1,3})", RegexOptions.IgnoreCase);
            if (mDur.Success && int.TryParse(mDur.Groups[1].Value, out int dur))
            {
                dur = Math.Max(1, Math.Min(120, dur));
                Action setDur = () => numTimeDelay.Value = Math.Min(numTimeDelay.Maximum, Math.Max(numTimeDelay.Minimum, dur));
                if (numTimeDelay.InvokeRequired) numTimeDelay.BeginInvoke(setDur); else setDur();
                _tcsDur?.TrySetResult(dur);
                return;
            }

            // --- DIM=15 % ---
            var mDim = Regex.Match(line, @"DIM\s*=\s*(\d{1,3})", RegexOptions.IgnoreCase);
            if (mDim.Success && int.TryParse(mDim.Groups[1].Value, out int dim))
            {
                dim = Math.Max(10, Math.Min(100, dim));
                Action setDim = () => numLowMode.Value = Math.Min(numLowMode.Maximum, Math.Max(numLowMode.Minimum, dim));
                if (numLowMode.InvokeRequired) numLowMode.BeginInvoke(setDim); else setDim();
                _tcsDim?.TrySetResult(dim);
                return;
            }

            // --- HI=50 % (tolère écho "<,GETHI,>") ---
            // si ton .NET est ancien, n’utilise pas Replace(..., StringComparison);
            line = Regex.Replace(line, "<,GETHI,>", "", RegexOptions.IgnoreCase);
            var mHi = Regex.Match(line, @"HI\s*=\s*(\d{1,3})", RegexOptions.IgnoreCase);
            if (mHi.Success && int.TryParse(mHi.Groups[1].Value, out int hi))
            {
                hi = Math.Max(1, Math.Min(100, hi));
                Action setHi = () => numHightMode.Value = Math.Min(numHightMode.Maximum, Math.Max(numHightMode.Minimum, hi));
                if (numHightMode.InvokeRequired) numHightMode.BeginInvoke(setHi); else setHi();
                _tcsHi?.TrySetResult(hi);
                return;
            }

            // --- ID: "Programmed ID is 12345678" ou "ID=12345678" ---
            var mIdProg = Regex.Match(line, @"Programmed\s+ID\s+is\s+(\d{8})", RegexOptions.IgnoreCase);
            var mIdEq = Regex.Match(line, @"\bID\s*=\s*(\d{8})", RegexOptions.IgnoreCase);
            if (mIdProg.Success || mIdEq.Success)
            {
                string idStr = mIdProg.Success ? mIdProg.Groups[1].Value : mIdEq.Groups[1].Value;
                if (int.TryParse(idStr, out int idVal))
                {
                    // si tu utilises MaskedTextBox ‘maskedID’
                    Action setId = () => maskedID.Text = idVal.ToString("D8");
                    if (maskedID.InvokeRequired) maskedID.BeginInvoke(setId); else setId();

                    _tcsId?.TrySetResult(idVal);
                }
                return;
            }

            // … tu peux ajouter ici GETMOTION/GETREMAIN si besoin
        }


        private static string OnlyDigits(string s)
        {
            var sb = new StringBuilder(s.Length);
            foreach (char c in s) if (char.IsDigit(c)) sb.Append(c);
            return sb.ToString();
        }

        // Retourne l’ID sous forme EXACTEMENT 8 chiffres (zéro-pad si besoin) à partir du MaskedTextBox
        private string GetId8FromMasked()
        {
            string raw = maskedID.Text ?? "";
            string digits = OnlyDigits(raw);
            if (digits.Length > 8) digits = digits.Substring(0, 8);
            return digits.PadLeft(8, '0');
        }

        // Essaie de convertir l’ID du MaskedTextBox en int (0..99999999)
        private bool TryGetIdFromMasked(out int id)
        {
            string id8 = GetId8FromMasked();
            return int.TryParse(id8, out id);
        }

        // Écrit un entier 0..99999999 dans le MaskedTextBox avec zéro-padding 8 chiffres
        private void SetMaskedIdFromInt(int id)
        {
            if (id < 0) id = 0;
            if (id > 99999999) id = 99999999;
            string id8 = id.ToString("D8");
            if (maskedID.InvokeRequired)
                maskedID.BeginInvoke(new Action(() => maskedID.Text = id8));
            else
                maskedID.Text = id8;
        }


        // Petit helper pour respecter les bornes du NumericUpDown
        private static decimal ClampNud(NumericUpDown nud, int v)
    {
        return Math.Min(nud.Maximum, Math.Max(nud.Minimum, v));
    }



    private decimal Clamp(NumericUpDown nud, int v)
    {
        return Math.Min(nud.Maximum, Math.Max(nud.Minimum, v));
    }
   
    private void diagnostique_port_receive_line(string line)
        {

            Comm_LineReceived(line); // réutilise le même parsing
        }

        private string BuildCmd(string s)
        {
            if (cbxCR.Checked) s += "\r";
            if (cbxLF.Checked) s += "\n";
            return s;
        }

        private async void btnWrite_Click(object sender, EventArgs e)
        {
            btnWrite.Enabled = false;
            try
            {
                // Récupère les valeurs UI
                int hi = (int)numHightMode.Value;   // 1..100
                int minutes = (int)numTimeDelay.Value;   // 1..120
                int percent = (int)numLowMode.Value;     // 0..100

                // Validation ID stricte: exactement 8 chiffres dans maskedID
                string id8 = GetId8();
                if (string.IsNullOrEmpty(id8))
                {
                    MessageBox.Show("L'ID doit contenir exactement 8 chiffres (00000000..99999999).",
                                    "ID invalide", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Envoi: SETDUR, SETDIM, SETID (espacés légèrement)
                comm.WriteData(BuildCmd($"<,SETDUR,{minutes:00},>"));
                await Task.Delay(80);

                // SETHI (nouvelle commande)
                comm.WriteData(BuildCmd($"<,SETHI,{hi},>"));
                await Task.Delay(80);

                comm.WriteData(BuildCmd($"<,SETDIM,{percent},>"));
                await Task.Delay(80);

                comm.WriteData(BuildCmd($"<,SETID,{id8},>"));
                await Task.Delay(80);

                // Vérification: GETDUR
                _tcsDur = new TaskCompletionSource<int>();
                comm.WriteData(BuildCmd("<,GETDUR,>"));
                await Task.WhenAny(_tcsDur.Task, Task.Delay(1500));

                // Vérification: GETDIM
                _tcsDim = new TaskCompletionSource<int>();
                comm.WriteData(BuildCmd("<,GETDIM,>"));
                await Task.WhenAny(_tcsDim.Task, Task.Delay(1500));

                // Vérification: GETID
                _tcsId = new TaskCompletionSource<int>();
                comm.WriteData(BuildCmd("<,GETID,>"));
                var done = await Task.WhenAny(_tcsId.Task, Task.Delay(1500));
                if (done != _tcsId.Task)
                    rtbDisplay.AppendText("[WARN] GETID verify timeout\r\n");
            }
            finally
            {
                btnWrite.Enabled = true;
            }
        }

        private void SaveToFile(string path, string text, bool append = false)
        {
            // Normalise les fins de ligne
            string normalized = text
                .Replace("\r\n", "\n")
                .Replace("\r", "\n")
                .Replace("\n", Environment.NewLine);

            bool fileExists = File.Exists(path);
            bool addHeader = append && fileExists;

            using (var sw = new StreamWriter(path, append, new UTF8Encoding(encoderShouldEmitUTF8Identifier: false)))
            {
                if (addHeader)
                {
                    sw.WriteLine();
                    sw.WriteLine($"----- Session {DateTime.Now:yyyy-MM-dd HH:mm:ss} -----");
                }

                sw.Write(normalized);

                if (append)
                    sw.WriteLine(); // séparation douce en fin d’ajout
            }
        }


        private void btnSave_Click(object sender, EventArgs e)
        {
            // Si une sélection existe, on propose d’enregistrer seulement la sélection,
            // sinon tout le contenu.
            string content = rtbDisplay.SelectionLength > 0 ? rtbDisplay.SelectedText : rtbDisplay.Text;

            using (var dlg = new SaveFileDialog()
            {
                Title = "Enregistrer le log",
                Filter = "Fichiers texte (*.txt)|*.txt|Tous les fichiers (*.*)|*.*",
                FileName = $"Log_{DateTime.Now:yyyyMMdd_HHmmss}.txt",
                OverwritePrompt = true
            })
            {
                if (dlg.ShowDialog(this) == DialogResult.OK)
                {
                    try
                    {
                        // Écrit en UTF-8 sans BOM
                        // File.WriteAllText(dlg.FileName, content, new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));
                        SaveToFile(dlg.FileName, content, append: true);
                        MessageBox.Show($"Sauvegardé :\r\n{dlg.FileName}", "OK",
                                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Erreur d'enregistrement :\r\n" + ex.Message,
                                        "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
       
        }

 
        // Handshake: envoie <,INFO,> et attend "INFO: ..." (avec N tentatives)
        private async System.Threading.Tasks.Task<bool> HandshakeAsync(int attempts = 2, int timeoutMs = 2000)
        {
            comm.CurrentTransmissionType = CommunicationManager.TransmissionType.Text;

            string tx = "<,INFO,>";
            if (cbxCR.Checked) tx += "\r";
            if (cbxLF.Checked) tx += "\n";

            for (int i = 0; i < attempts; i++)
            {
                _tcsInfo = new System.Threading.Tasks.TaskCompletionSource<bool>();
                comm.WriteData(tx);

                var done = await System.Threading.Tasks.Task.WhenAny(_tcsInfo.Task, System.Threading.Tasks.Task.Delay(timeoutMs));
                if (done == _tcsInfo.Task && _tcsInfo.Task.Result)
                    return true; // reçu
            }
            return false; // échec après N tentatives
        }

        // Bouton Diagnostic
       

        // --- Helpers ID (MaskedTextBox) ---
        private string GetId8()
        {
            string t = maskedID?.Text?.Trim() ?? "";
            return (t.Length == 8 && int.TryParse(t, out _)) ? t : string.Empty;
        }
        private void SetId8(int id)
        {
            if (maskedID != null) maskedID.Text = id.ToString("00000000");
        }

        private async void btnDiag_Click_1(object sender, EventArgs e)
        {
            {
                btnDiag.Enabled = false;

                bool mustCloseAfter = false;
                try
                {
                    // Si le port n’est pas ouvert, on l’ouvre temporairement
                    if (!cmdClose.Enabled) // ton UI met cmdClose.Enabled=true quand le port est ouvert
                    {
                        // Config rapide (mêmes champs que cmdOpen_Click)
                        comm.Parity = cboParity.Text;
                        comm.StopBits = cboStop.Text;
                        comm.DataBits = cboData.Text;
                        comm.BaudRate = cboBaud.Text;
                        comm.DisplayWindow = rtbDisplay;
                        comm.PortName = cboPort.SelectedItem?.ToString();
                        comm.CurrentTransmissionType = CommunicationManager.TransmissionType.Text;

                        if (string.IsNullOrWhiteSpace(comm.PortName))
                        {
                            MessageBox.Show("Choisissez un port série.", "Diagnostic", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                        if (!comm.OpenPort())
                        {
                            MessageBox.Show("Impossible d’ouvrir le port pour le diagnostic.", "Diagnostic", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                        mustCloseAfter = true; // on refermera après le test
                    }

                    // Handshake
                    bool ok = await HandshakeAsync(attempts: 2, timeoutMs: 2000);

                    if (ok)
                    {
                        MessageBox.Show("Diagnostic OK : réponse INFO reçue.\nLe MCU est joignable et le port est prêt.",
                                        "Diagnostic", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        // (optionnel) demander un statut compact
                        // comm.WriteData("<,PRINTCFGLN,>");
                    }
                    else
                    {
                        // si on a ouvert temporairement, on ferme; sinon on laisse tel quel
                        if (mustCloseAfter)
                            comm.closePort();

                        MessageBox.Show("Diagnostic ÉCHEC : aucune réponse INFO.\nVérifiez câblage, alimentation, baud/parité/stop, MCU.",
                                        "Diagnostic", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    try { if (mustCloseAfter) comm.closePort(); } catch { }
                    MessageBox.Show("Erreur pendant le diagnostic :\n" + ex.Message, "Diagnostic", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    btnDiag.Enabled = true;
                }
            }
        }

        private async void btnIDwrite_Click(object sender, EventArgs e)
        {
            btnIDwrite.Enabled = false;
            try
            {
                

                // Validation ID stricte: exactement 8 chiffres dans maskedID
                string id8 = GetId8();
                if (string.IsNullOrEmpty(id8))
                {
                    MessageBox.Show("L'ID doit contenir exactement 8 chiffres (00000000..99999999).",
                                    "ID invalide", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                comm.WriteData(BuildCmd($"<,SETID,{id8},>"));
                await Task.Delay(80);
                // Vérification: GETID
                _tcsId = new TaskCompletionSource<int>();
                comm.WriteData(BuildCmd("<,GETID,>"));
                var done = await Task.WhenAny(_tcsId.Task, Task.Delay(1500));
                if (done != _tcsId.Task)
                    rtbDisplay.AppendText("[WARN] GETID verify timeout\r\n");
            }
            finally
            {
                btnIDwrite.Enabled = true;
            }
        }

        private async void btnIDRead_Click(object sender, EventArgs e)
        {

           
                btnIDRead.Enabled = false;
                try
                {


                    
                    // Vérification: GETID
                    _tcsId = new TaskCompletionSource<int>();
                    comm.WriteData(BuildCmd("<,GETID,>"));
                    var done = await Task.WhenAny(_tcsId.Task, Task.Delay(1500));
                    if (done != _tcsId.Task)
                        rtbDisplay.AppendText("[WARN] GETID verify timeout\r\n");
                }
                finally
                {
                    btnIDRead.Enabled = true;
                }
            


        }
    }
    

}