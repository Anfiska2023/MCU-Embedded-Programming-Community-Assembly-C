namespace PCComm
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.zoomdec = new System.Windows.Forms.Button();
            this.cbxLF = new System.Windows.Forms.CheckBox();
            this.ZoomInc = new System.Windows.Forms.Button();
            this.cbxCR = new System.Windows.Forms.CheckBox();
            this.cmdClose = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rdoHex = new System.Windows.Forms.RadioButton();
            this.rdoText = new System.Windows.Forms.RadioButton();
            this.btnClear = new System.Windows.Forms.Button();
            this.cmdOpen = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.cbxMSLC = new System.Windows.Forms.CheckBox();
            this.cbxDACT = new System.Windows.Forms.CheckBox();
            this.cbxMS = new System.Windows.Forms.CheckBox();
            this.gbxUSER = new System.Windows.Forms.GroupBox();
            this.cbxMSS = new System.Windows.Forms.CheckBox();
            this.cbxGG = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cb_commande = new System.Windows.Forms.ComboBox();
            this.cboPort = new System.Windows.Forms.ComboBox();
            this.cboBaud = new System.Windows.Forms.ComboBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.cboParity = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cboStop = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cboData = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Exit = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.rtbDisplay = new System.Windows.Forms.RichTextBox();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.btnDiag = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.comportset = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnIDRead = new System.Windows.Forms.Button();
            this.btnIDwrite = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.maskedID = new System.Windows.Forms.MaskedTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.numLowMode = new System.Windows.Forms.NumericUpDown();
            this.numHightMode = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.numTimeDelay = new System.Windows.Forms.NumericUpDown();
            this.btnWrite = new System.Windows.Forms.Button();
            this.btxREAD = new System.Windows.Forms.Button();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.txtSend = new System.Windows.Forms.TextBox();
            this.cmdSend = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.gbxUSER.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.comportset.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLowMode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numHightMode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTimeDelay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // zoomdec
            // 
            this.zoomdec.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.zoomdec.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.zoomdec.ForeColor = System.Drawing.Color.Yellow;
            this.zoomdec.Location = new System.Drawing.Point(215, 492);
            this.zoomdec.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.zoomdec.Name = "zoomdec";
            this.zoomdec.Size = new System.Drawing.Size(98, 28);
            this.zoomdec.TabIndex = 10;
            this.zoomdec.Text = "Text Size -";
            this.zoomdec.UseVisualStyleBackColor = true;
            this.zoomdec.Click += new System.EventHandler(this.zoomdec_Click);
            // 
            // cbxLF
            // 
            this.cbxLF.AutoSize = true;
            this.cbxLF.Location = new System.Drawing.Point(66, 50);
            this.cbxLF.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxLF.Name = "cbxLF";
            this.cbxLF.Size = new System.Drawing.Size(47, 25);
            this.cbxLF.TabIndex = 13;
            this.cbxLF.Text = "LF";
            this.cbxLF.UseVisualStyleBackColor = true;
            // 
            // ZoomInc
            // 
            this.ZoomInc.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.ZoomInc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ZoomInc.ForeColor = System.Drawing.Color.Yellow;
            this.ZoomInc.Location = new System.Drawing.Point(215, 524);
            this.ZoomInc.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.ZoomInc.Name = "ZoomInc";
            this.ZoomInc.Size = new System.Drawing.Size(98, 26);
            this.ZoomInc.TabIndex = 9;
            this.ZoomInc.Text = "Text Size +";
            this.ZoomInc.UseVisualStyleBackColor = true;
            this.ZoomInc.Click += new System.EventHandler(this.ZoomInc_Click);
            // 
            // cbxCR
            // 
            this.cbxCR.AutoSize = true;
            this.cbxCR.Location = new System.Drawing.Point(8, 53);
            this.cbxCR.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxCR.Name = "cbxCR";
            this.cbxCR.Size = new System.Drawing.Size(50, 25);
            this.cbxCR.TabIndex = 14;
            this.cbxCR.Text = "CR";
            this.cbxCR.UseVisualStyleBackColor = true;
            // 
            // cmdClose
            // 
            this.cmdClose.AutoSize = true;
            this.cmdClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdClose.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.cmdClose.Location = new System.Drawing.Point(11, 590);
            this.cmdClose.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cmdClose.Name = "cmdClose";
            this.cmdClose.Size = new System.Drawing.Size(98, 33);
            this.cmdClose.TabIndex = 5;
            this.cmdClose.Text = "Disconnect";
            this.cmdClose.UseVisualStyleBackColor = true;
            this.cmdClose.Click += new System.EventHandler(this.cmdClose_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cbxLF);
            this.groupBox3.Controls.Add(this.rdoHex);
            this.groupBox3.Controls.Add(this.cbxCR);
            this.groupBox3.Controls.Add(this.rdoText);
            this.groupBox3.ForeColor = System.Drawing.Color.Yellow;
            this.groupBox3.Location = new System.Drawing.Point(217, 406);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox3.Size = new System.Drawing.Size(126, 86);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Format";
            // 
            // rdoHex
            // 
            this.rdoHex.AutoSize = true;
            this.rdoHex.Location = new System.Drawing.Point(66, 19);
            this.rdoHex.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.rdoHex.Name = "rdoHex";
            this.rdoHex.Size = new System.Drawing.Size(57, 25);
            this.rdoHex.TabIndex = 0;
            this.rdoHex.TabStop = true;
            this.rdoHex.Text = "Hex";
            this.rdoHex.UseVisualStyleBackColor = true;
            this.rdoHex.CheckedChanged += new System.EventHandler(this.rdoHex_CheckedChanged);
            // 
            // rdoText
            // 
            this.rdoText.AutoSize = true;
            this.rdoText.Location = new System.Drawing.Point(8, 19);
            this.rdoText.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.rdoText.Name = "rdoText";
            this.rdoText.Size = new System.Drawing.Size(58, 25);
            this.rdoText.TabIndex = 1;
            this.rdoText.TabStop = true;
            this.rdoText.Text = "Text";
            this.rdoText.UseVisualStyleBackColor = true;
            // 
            // btnClear
            // 
            this.btnClear.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClear.ForeColor = System.Drawing.Color.Yellow;
            this.btnClear.Location = new System.Drawing.Point(482, 562);
            this.btnClear.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(74, 34);
            this.btnClear.TabIndex = 15;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // cmdOpen
            // 
            this.cmdOpen.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdOpen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdOpen.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.cmdOpen.Location = new System.Drawing.Point(112, 590);
            this.cmdOpen.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cmdOpen.Name = "cmdOpen";
            this.cmdOpen.Size = new System.Drawing.Size(92, 33);
            this.cmdOpen.TabIndex = 8;
            this.cmdOpen.Text = "Connect";
            this.cmdOpen.UseVisualStyleBackColor = true;
            this.cmdOpen.Click += new System.EventHandler(this.cmdOpen_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Black;
            this.groupBox2.Controls.Add(this.groupBox6);
            this.groupBox2.Controls.Add(this.gbxUSER);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.cb_commande);
            this.groupBox2.ForeColor = System.Drawing.Color.Yellow;
            this.groupBox2.Location = new System.Drawing.Point(694, 3);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox2.Size = new System.Drawing.Size(444, 400);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Commandes Predefini";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.checkBox1);
            this.groupBox6.Controls.Add(this.cbxMSLC);
            this.groupBox6.Controls.Add(this.cbxDACT);
            this.groupBox6.Controls.Add(this.cbxMS);
            this.groupBox6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.groupBox6.Location = new System.Drawing.Point(5, 174);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(250, 135);
            this.groupBox6.TabIndex = 21;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Admin";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(7, 22);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(172, 25);
            this.checkBox1.TabIndex = 26;
            this.checkBox1.Text = "Motion Sensor tests";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // cbxMSLC
            // 
            this.cbxMSLC.AutoSize = true;
            this.cbxMSLC.Location = new System.Drawing.Point(7, 47);
            this.cbxMSLC.Name = "cbxMSLC";
            this.cbxMSLC.Size = new System.Drawing.Size(228, 25);
            this.cbxMSLC.TabIndex = 27;
            this.cbxMSLC.Text = "Motion Sensor Logic Change";
            this.cbxMSLC.UseVisualStyleBackColor = true;
            this.cbxMSLC.CheckedChanged += new System.EventHandler(this.cbxMSLC_CheckedChanged);
            // 
            // cbxDACT
            // 
            this.cbxDACT.AutoSize = true;
            this.cbxDACT.Location = new System.Drawing.Point(7, 72);
            this.cbxDACT.Name = "cbxDACT";
            this.cbxDACT.Size = new System.Drawing.Size(99, 25);
            this.cbxDACT.TabIndex = 28;
            this.cbxDACT.Text = "DAC tests";
            this.cbxDACT.UseVisualStyleBackColor = true;
            this.cbxDACT.CheckedChanged += new System.EventHandler(this.cbxDACT_CheckedChanged);
            // 
            // cbxMS
            // 
            this.cbxMS.AutoSize = true;
            this.cbxMS.Location = new System.Drawing.Point(7, 97);
            this.cbxMS.Name = "cbxMS";
            this.cbxMS.Size = new System.Drawing.Size(148, 25);
            this.cbxMS.TabIndex = 22;
            this.cbxMS.Text = "SystemTick tests";
            this.cbxMS.UseVisualStyleBackColor = true;
            this.cbxMS.CheckedChanged += new System.EventHandler(this.cbxMS_CheckedChanged);
            // 
            // gbxUSER
            // 
            this.gbxUSER.Controls.Add(this.cbxMSS);
            this.gbxUSER.Controls.Add(this.cbxGG);
            this.gbxUSER.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.gbxUSER.Location = new System.Drawing.Point(7, 89);
            this.gbxUSER.Name = "gbxUSER";
            this.gbxUSER.Size = new System.Drawing.Size(250, 79);
            this.gbxUSER.TabIndex = 29;
            this.gbxUSER.TabStop = false;
            this.gbxUSER.Text = "Utilisateur";
            // 
            // cbxMSS
            // 
            this.cbxMSS.AutoSize = true;
            this.cbxMSS.Location = new System.Drawing.Point(6, 48);
            this.cbxMSS.Name = "cbxMSS";
            this.cbxMSS.Size = new System.Drawing.Size(233, 25);
            this.cbxMSS.TabIndex = 24;
            this.cbxMSS.Text = "Motion Sensor Programming";
            this.cbxMSS.UseVisualStyleBackColor = true;
            this.cbxMSS.CheckedChanged += new System.EventHandler(this.cbxMSS_CheckedChanged);
            // 
            // cbxGG
            // 
            this.cbxGG.AutoSize = true;
            this.cbxGG.Location = new System.Drawing.Point(7, 26);
            this.cbxGG.Name = "cbxGG";
            this.cbxGG.Size = new System.Drawing.Size(86, 25);
            this.cbxGG.TabIndex = 23;
            this.cbxGG.Text = "General";
            this.cbxGG.UseVisualStyleBackColor = true;
            this.cbxGG.CheckedChanged += new System.EventHandler(this.cbxGG_CheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 65);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(421, 21);
            this.label7.TabIndex = 25;
            this.label7.Text = "Les Groupes des Commandes predefini (choisir pour active)";
            // 
            // cb_commande
            // 
            this.cb_commande.DropDownHeight = 600;
            this.cb_commande.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_commande.DropDownWidth = 500;
            this.cb_commande.FormattingEnabled = true;
            this.cb_commande.IntegralHeight = false;
            this.cb_commande.Location = new System.Drawing.Point(5, 29);
            this.cb_commande.Name = "cb_commande";
            this.cb_commande.Size = new System.Drawing.Size(350, 27);
            this.cb_commande.TabIndex = 20;
            this.cb_commande.SelectedIndexChanged += new System.EventHandler(this.cb_commande_SelectedIndexChanged);
            // 
            // cboPort
            // 
            this.cboPort.FormattingEnabled = true;
            this.cboPort.Location = new System.Drawing.Point(106, 22);
            this.cboPort.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cboPort.Name = "cboPort";
            this.cboPort.Size = new System.Drawing.Size(87, 27);
            this.cboPort.TabIndex = 10;
            this.cboPort.Tag = "";
            // 
            // cboBaud
            // 
            this.cboBaud.FormattingEnabled = true;
            this.cboBaud.Items.AddRange(new object[] {
            "300",
            "600",
            "1200",
            "2400",
            "4800",
            "115200",
            "9600",
            "14400",
            "28800",
            "38400",
            "57600",
            "115200",
            "230400",
            "250000",
            "500000",
            "1000000"});
            this.cboBaud.Location = new System.Drawing.Point(106, 53);
            this.cboBaud.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cboBaud.Name = "cboBaud";
            this.cboBaud.Size = new System.Drawing.Size(87, 27);
            this.cboBaud.TabIndex = 11;
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label1.Location = new System.Drawing.Point(18, 28);
            this.Label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(40, 21);
            this.Label1.TabIndex = 15;
            this.Label1.Text = "Port";
            // 
            // cboParity
            // 
            this.cboParity.FormattingEnabled = true;
            this.cboParity.Location = new System.Drawing.Point(106, 85);
            this.cboParity.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cboParity.Name = "cboParity";
            this.cboParity.Size = new System.Drawing.Size(87, 27);
            this.cboParity.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label2.Location = new System.Drawing.Point(18, 65);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 21);
            this.label2.TabIndex = 16;
            this.label2.Text = "Baud Rate";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label3.Location = new System.Drawing.Point(18, 91);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 21);
            this.label3.TabIndex = 17;
            this.label3.Text = "Parity";
            // 
            // cboStop
            // 
            this.cboStop.FormattingEnabled = true;
            this.cboStop.Location = new System.Drawing.Point(106, 117);
            this.cboStop.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cboStop.Name = "cboStop";
            this.cboStop.Size = new System.Drawing.Size(87, 27);
            this.cboStop.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label4.Location = new System.Drawing.Point(18, 124);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 21);
            this.label4.TabIndex = 18;
            this.label4.Text = "Stop Bits";
            // 
            // cboData
            // 
            this.cboData.FormattingEnabled = true;
            this.cboData.Items.AddRange(new object[] {
            "7",
            "8",
            "9"});
            this.cboData.Location = new System.Drawing.Point(106, 148);
            this.cboData.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cboData.Name = "cboData";
            this.cboData.Size = new System.Drawing.Size(87, 27);
            this.cboData.TabIndex = 14;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label5.Location = new System.Drawing.Point(18, 150);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 21);
            this.label5.TabIndex = 19;
            this.label5.Text = "Data Bits";
            // 
            // Exit
            // 
            this.Exit.BackColor = System.Drawing.Color.Black;
            this.Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Exit.ForeColor = System.Drawing.Color.Yellow;
            this.Exit.Location = new System.Drawing.Point(563, 561);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(62, 35);
            this.Exit.TabIndex = 16;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = false;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.Yellow;
            this.button1.Location = new System.Drawing.Point(631, 561);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(63, 35);
            this.button1.TabIndex = 17;
            this.button1.Text = "Help";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // rtbDisplay
            // 
            this.rtbDisplay.BackColor = System.Drawing.Color.Black;
            this.rtbDisplay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rtbDisplay.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbDisplay.ForeColor = System.Drawing.Color.White;
            this.rtbDisplay.Location = new System.Drawing.Point(9, 25);
            this.rtbDisplay.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.rtbDisplay.Name = "rtbDisplay";
            this.rtbDisplay.Size = new System.Drawing.Size(662, 334);
            this.rtbDisplay.TabIndex = 3;
            this.rtbDisplay.Text = "";
            this.rtbDisplay.WordWrap = false;
            this.rtbDisplay.ZoomFactor = 1.4F;
            this.rtbDisplay.TextChanged += new System.EventHandler(this.rtbDisplay_TextChanged);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.btnDiag);
            this.splitContainer1.Panel1.Controls.Add(this.btnSave);
            this.splitContainer1.Panel1.Controls.Add(this.comportset);
            this.splitContainer1.Panel1.Controls.Add(this.groupBox4);
            this.splitContainer1.Panel1.Controls.Add(this.groupBox2);
            this.splitContainer1.Panel1.Controls.Add(this.Exit);
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            this.splitContainer1.Panel1.Controls.Add(this.button1);
            this.splitContainer1.Panel1.Controls.Add(this.zoomdec);
            this.splitContainer1.Panel1.Controls.Add(this.ZoomInc);
            this.splitContainer1.Panel1.Controls.Add(this.cmdClose);
            this.splitContainer1.Panel1.Controls.Add(this.btnClear);
            this.splitContainer1.Panel1.Controls.Add(this.groupBox3);
            this.splitContainer1.Panel1.Controls.Add(this.cmdOpen);
            this.splitContainer1.Panel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.BackColor = System.Drawing.Color.Black;
            this.splitContainer1.Panel2.ForeColor = System.Drawing.Color.Yellow;
            this.splitContainer1.Panel2.Tag = "";
            this.splitContainer1.Size = new System.Drawing.Size(985, 837);
            this.splitContainer1.SplitterDistance = 942;
            this.splitContainer1.TabIndex = 16;
            // 
            // btnDiag
            // 
            this.btnDiag.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDiag.Location = new System.Drawing.Point(216, 589);
            this.btnDiag.Name = "btnDiag";
            this.btnDiag.Size = new System.Drawing.Size(97, 34);
            this.btnDiag.TabIndex = 23;
            this.btnDiag.Text = "Diagnostic";
            this.btnDiag.UseVisualStyleBackColor = true;
            this.btnDiag.Click += new System.EventHandler(this.btnDiag_Click_1);
            // 
            // btnSave
            // 
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnSave.Location = new System.Drawing.Point(215, 554);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(98, 33);
            this.btnSave.TabIndex = 22;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // comportset
            // 
            this.comportset.Controls.Add(this.cboPort);
            this.comportset.Controls.Add(this.Label1);
            this.comportset.Controls.Add(this.cboBaud);
            this.comportset.Controls.Add(this.label2);
            this.comportset.Controls.Add(this.cboParity);
            this.comportset.Controls.Add(this.label3);
            this.comportset.Controls.Add(this.cboStop);
            this.comportset.Controls.Add(this.label4);
            this.comportset.Controls.Add(this.cboData);
            this.comportset.Controls.Add(this.label5);
            this.comportset.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.comportset.Location = new System.Drawing.Point(11, 406);
            this.comportset.Name = "comportset";
            this.comportset.Size = new System.Drawing.Size(200, 178);
            this.comportset.TabIndex = 21;
            this.comportset.TabStop = false;
            this.comportset.Text = "Serial";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnIDRead);
            this.groupBox4.Controls.Add(this.btnIDwrite);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.maskedID);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.numLowMode);
            this.groupBox4.Controls.Add(this.numHightMode);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.numTimeDelay);
            this.groupBox4.Controls.Add(this.btnWrite);
            this.groupBox4.Controls.Add(this.btxREAD);
            this.groupBox4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.groupBox4.Location = new System.Drawing.Point(347, 406);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(347, 149);
            this.groupBox4.TabIndex = 20;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Configuration Board MSIREEFP";
            this.groupBox4.Visible = false;
            // 
            // btnIDRead
            // 
            this.btnIDRead.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnIDRead.Location = new System.Drawing.Point(157, 104);
            this.btnIDRead.Name = "btnIDRead";
            this.btnIDRead.Size = new System.Drawing.Size(71, 27);
            this.btnIDRead.TabIndex = 36;
            this.btnIDRead.Text = "Get ID";
            this.btnIDRead.UseVisualStyleBackColor = true;
            this.btnIDRead.Click += new System.EventHandler(this.btnIDRead_Click);
            // 
            // btnIDwrite
            // 
            this.btnIDwrite.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnIDwrite.Location = new System.Drawing.Point(89, 104);
            this.btnIDwrite.Name = "btnIDwrite";
            this.btnIDwrite.Size = new System.Drawing.Size(62, 27);
            this.btnIDwrite.TabIndex = 35;
            this.btnIDwrite.Text = "Set ID";
            this.btnIDwrite.UseVisualStyleBackColor = true;
            this.btnIDwrite.Click += new System.EventHandler(this.btnIDwrite_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(191, 27);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(95, 21);
            this.label10.TabIndex = 34;
            this.label10.Text = "Low Mode   ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(99, 27);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 21);
            this.label9.TabIndex = 33;
            this.label9.Text = "Time Delay";
            // 
            // maskedID
            // 
            this.maskedID.HidePromptOnLeave = true;
            this.maskedID.Location = new System.Drawing.Point(10, 105);
            this.maskedID.Mask = "00000000";
            this.maskedID.Name = "maskedID";
            this.maskedID.RejectInputOnFirstFailure = true;
            this.maskedID.ResetOnSpace = false;
            this.maskedID.Size = new System.Drawing.Size(73, 27);
            this.maskedID.TabIndex = 23;
            this.maskedID.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 81);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 21);
            this.label8.TabIndex = 30;
            this.label8.Text = "numero ID";
            // 
            // numLowMode
            // 
            this.numLowMode.Location = new System.Drawing.Point(195, 51);
            this.numLowMode.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numLowMode.Name = "numLowMode";
            this.numLowMode.Size = new System.Drawing.Size(55, 27);
            this.numLowMode.TabIndex = 32;
            this.numLowMode.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // numHightMode
            // 
            this.numHightMode.Location = new System.Drawing.Point(10, 51);
            this.numHightMode.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.numHightMode.Name = "numHightMode";
            this.numHightMode.Size = new System.Drawing.Size(55, 27);
            this.numHightMode.TabIndex = 31;
            this.numHightMode.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 21);
            this.label6.TabIndex = 30;
            this.label6.Text = "Hight Mode   ";
            // 
            // numTimeDelay
            // 
            this.numTimeDelay.Location = new System.Drawing.Point(103, 51);
            this.numTimeDelay.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numTimeDelay.Name = "numTimeDelay";
            this.numTimeDelay.Size = new System.Drawing.Size(55, 27);
            this.numTimeDelay.TabIndex = 2;
            this.numTimeDelay.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // btnWrite
            // 
            this.btnWrite.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWrite.Location = new System.Drawing.Point(283, 66);
            this.btnWrite.Name = "btnWrite";
            this.btnWrite.Size = new System.Drawing.Size(62, 43);
            this.btnWrite.TabIndex = 1;
            this.btnWrite.Text = "Write";
            this.btnWrite.UseVisualStyleBackColor = true;
            this.btnWrite.Click += new System.EventHandler(this.btnWrite_Click);
            // 
            // btxREAD
            // 
            this.btxREAD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btxREAD.Location = new System.Drawing.Point(283, 16);
            this.btxREAD.Name = "btxREAD";
            this.btxREAD.Size = new System.Drawing.Size(62, 44);
            this.btxREAD.TabIndex = 0;
            this.btxREAD.Text = "Read";
            this.btxREAD.UseVisualStyleBackColor = true;
            this.btxREAD.Click += new System.EventHandler(this.btxREAD_Click);
            // 
            // splitContainer2
            // 
            this.splitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer2.IsSplitterFixed = true;
            this.splitContainer2.Location = new System.Drawing.Point(11, 3);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.splitContainer3);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.groupBox1);
            this.splitContainer2.Size = new System.Drawing.Size(676, 400);
            this.splitContainer2.SplitterDistance = 36;
            this.splitContainer2.TabIndex = 0;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.BackColor = System.Drawing.Color.Black;
            this.splitContainer3.Panel1.Controls.Add(this.txtSend);
            this.splitContainer3.Panel1.ForeColor = System.Drawing.Color.Yellow;
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.BackColor = System.Drawing.Color.Black;
            this.splitContainer3.Panel2.Controls.Add(this.cmdSend);
            this.splitContainer3.Panel2.ForeColor = System.Drawing.Color.Yellow;
            this.splitContainer3.Size = new System.Drawing.Size(676, 36);
            this.splitContainer3.SplitterDistance = 582;
            this.splitContainer3.TabIndex = 0;
            // 
            // txtSend
            // 
            this.txtSend.BackColor = System.Drawing.Color.White;
            this.txtSend.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSend.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtSend.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSend.ForeColor = System.Drawing.Color.Maroon;
            this.txtSend.Location = new System.Drawing.Point(0, 10);
            this.txtSend.Margin = new System.Windows.Forms.Padding(4, 10, 4, 3);
            this.txtSend.Name = "txtSend";
            this.txtSend.Size = new System.Drawing.Size(582, 26);
            this.txtSend.TabIndex = 4;
            // 
            // cmdSend
            // 
            this.cmdSend.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdSend.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.cmdSend.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdSend.Location = new System.Drawing.Point(0, 9);
            this.cmdSend.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cmdSend.Name = "cmdSend";
            this.cmdSend.Size = new System.Drawing.Size(90, 27);
            this.cmdSend.TabIndex = 5;
            this.cmdSend.Text = "Send";
            this.cmdSend.UseVisualStyleBackColor = true;
            this.cmdSend.Click += new System.EventHandler(this.cmdSend_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Black;
            this.groupBox1.Controls.Add(this.rtbDisplay);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.ForeColor = System.Drawing.Color.Yellow;
            this.groupBox1.ImeMode = System.Windows.Forms.ImeMode.On;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(676, 360);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Console";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(985, 837);
            this.Controls.Add(this.splitContainer1);
            this.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "frmMain";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MS-IR-EE-FP Serial Test Terminal ";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.gbxUSER.ResumeLayout(false);
            this.gbxUSER.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.comportset.ResumeLayout(false);
            this.comportset.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLowMode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numHightMode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTimeDelay)).EndInit();
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button zoomdec;
        private System.Windows.Forms.CheckBox cbxLF;
        private System.Windows.Forms.Button ZoomInc;
        private System.Windows.Forms.CheckBox cbxCR;
        private System.Windows.Forms.Button cmdClose;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton rdoHex;
        private System.Windows.Forms.RadioButton rdoText;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button cmdOpen;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cb_commande;
        private System.Windows.Forms.ComboBox cboPort;
        private System.Windows.Forms.ComboBox cboBaud;
        private System.Windows.Forms.Label Label1;
        private System.Windows.Forms.ComboBox cboParity;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cboStop;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cboData;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RichTextBox rtbDisplay;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.TextBox txtSend;
        private System.Windows.Forms.Button cmdSend;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox cbxMS;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox cbxMSS;
        private System.Windows.Forms.CheckBox cbxGG;
        private System.Windows.Forms.CheckBox cbxDACT;
        private System.Windows.Forms.CheckBox cbxMSLC;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox gbxUSER;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown numTimeDelay;
        private System.Windows.Forms.Button btxREAD;
        private System.Windows.Forms.NumericUpDown numLowMode;
        private System.Windows.Forms.NumericUpDown numHightMode;
        private System.Windows.Forms.GroupBox comportset;
        private System.Windows.Forms.Button btnWrite;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.MaskedTextBox maskedID;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnDiag;
        private System.Windows.Forms.Button btnIDwrite;
        private System.Windows.Forms.Button btnIDRead;
    }
}