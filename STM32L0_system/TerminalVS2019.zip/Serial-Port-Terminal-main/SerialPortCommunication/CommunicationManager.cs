﻿using System;
using System.Text;
using System.Drawing;
using System.IO.Ports;
using System.Windows.Forms;

namespace PCComm
{
    class CommunicationManager
    {
       
        #region Manager Enums
        public enum TransmissionType { Text, Hex }
       
        public enum MessageType { Incoming, Outgoing, Normal, Warning, Error }
        #endregion

        #region Manager Variables
        // props/vars
        private string _baudRate = string.Empty;
        private string _parity = string.Empty;
        private string _stopBits = string.Empty;
        private string _dataBits = string.Empty;
        private string _portName = string.Empty;

        private TransmissionType _transType;
        private RichTextBox _displayWindow;

        private readonly Color[] MessageColor = { Color.White, Color.Green, Color.Black, Color.Orange, Color.Red };
        private readonly SerialPort comPort = new SerialPort();

        // ⇩⇩ UNE SEULE FOIS ⇩⇩
        public event Action<string> LineReceived;

        // seulement si tu t’en sers, sinon supprime
        // private readonly StringBuilder _lineBuf = new StringBuilder();
        #endregion

        #region Manager Properties
        /// <summary>
        /// Property to hold the BaudRate
        /// of our manager class
        /// </summary>
        public string BaudRate
        {
            get { return _baudRate; }
            set { _baudRate = value; }
        }

        /// <summary>
        /// property to hold the Parity
        /// of our manager class
        /// </summary>
        public string Parity
        {
            get { return _parity; }
            set { _parity = value; }
        }

        /// <summary>
        /// property to hold the StopBits
        /// of our manager class
        /// </summary>
        public string StopBits
        {
            get { return _stopBits; }
            set { _stopBits = value; }
        }

        /// <summary>
        /// property to hold the DataBits
        /// of our manager class
        /// </summary>
        public string DataBits
        {
            get { return _dataBits; }
            set { _dataBits = value; }
        }

        /// <summary>
        /// property to hold the PortName
        /// of our manager class
        /// </summary>
        public string PortName
        {
            get { return _portName; }
            set { _portName = value; }
        }

        /// <summary>
        /// property to hold our TransmissionType
        /// of our manager class
        /// </summary>
        public TransmissionType CurrentTransmissionType
        {
            get { return _transType; }
            set { _transType = value; }
        }

        /// <summary>
        /// property to hold our display window
        /// value
        /// </summary>
        public RichTextBox DisplayWindow
        {
            get { return _displayWindow; }
            set { _displayWindow = value; }
        }
        #endregion

        #region Manager Constructors
        /// <summary>
        /// Constructor to set the properties of our Manager Class
        /// </summary>
        /// <param name="baud">Desired BaudRate</param>
        /// <param name="par">Desired Parity</param>
        /// <param name="sBits">Desired StopBits</param>
        /// <param name="dBits">Desired DataBits</param>
        /// <param name="name">Desired PortName</param>
        public CommunicationManager(string baud, string par, string sBits, string dBits, string name, RichTextBox rtb)
        {
            _baudRate = baud;
            _parity = par;
            _stopBits = sBits;
            _dataBits = dBits;
            _portName = name;
            _displayWindow = rtb;
            //now add an event handler
            comPort.DataReceived += new SerialDataReceivedEventHandler(comPort_DataReceived);
        }

        /// <summary>
        /// Comstructor to set the properties of our
        /// serial port communicator to nothing
        /// </summary>
        public CommunicationManager()
        {
            _baudRate = string.Empty;
            _parity = string.Empty;
            _stopBits = string.Empty;
            _dataBits = string.Empty;
            _portName = "COM4";
            _displayWindow = null;
            //add event handler
            comPort.DataReceived += new SerialDataReceivedEventHandler(comPort_DataReceived);
        }
        #endregion

        #region WriteData
        public void WriteData(string msg)
        {
            switch (CurrentTransmissionType)
            {
                case TransmissionType.Text:
                    //first make sure the port is open
                    //if its not open then open it

                    //if (!(comPort.IsOpen == true)) comPort.Open();
                    //send the message to the port
                    comPort.WriteLine(msg);
                    //display the message
                    DisplayData(MessageType.Outgoing, msg);
                    break;
                case TransmissionType.Hex:
                    try
                    {
                        //convert the message to byte array
                        byte[] newMsg = HexToByte(msg);
                        //send the message to the port
                        comPort.Write(newMsg, 0, newMsg.Length);
                        //convert back to hex and display
                        DisplayData(MessageType.Outgoing, ByteToHex(newMsg) + "\n");
                    }
                    catch (FormatException ex)
                    {
                        //display error message
                        DisplayData(MessageType.Error, ex.Message);
                    }
                    finally
                    {
                        _displayWindow.SelectAll();
                    }
                    break;
                default:
                    //first make sure the port is open
                    //if its not open then open it
                    if (!(comPort.IsOpen == true)) comPort.Open();
                    //send the message to the port
                    comPort.Write(msg);
                    //display the message
                    DisplayData(MessageType.Outgoing, msg);
                    break;
            }
        }
        #endregion

        #region HexToByte
        /// <summary>
        /// method to convert hex string into a byte array
        /// </summary>
        /// <param name="msg">string to convert</param>
        /// <returns>a byte array</returns>
        private byte[] HexToByte(string msg)
        {
            //remove any spaces from the string
            msg = msg.Replace(" ", "");
            //create a byte array the length of the
            //divided by 2 (Hex is 2 characters in length)
            byte[] comBuffer = new byte[msg.Length / 2];
            //loop through the length of the provided string
            for (int i = 0; i < msg.Length; i += 2)
                //convert each set of 2 characters to a byte
                //and add to the array
                comBuffer[i / 2] = (byte)Convert.ToByte(msg.Substring(i, 2), 16);
            //return the array
            return comBuffer;
        }
        #endregion

        #region ByteToHex
        /// <summary>
        /// method to convert a byte array into a hex string
        /// </summary>
        /// <param name="comByte">byte array to convert</param>
        /// <returns>a hex string</returns>
        private string ByteToHex(byte[] comByte)
        {
            //create a new StringBuilder object
            StringBuilder builder = new StringBuilder(comByte.Length * 3);
            //loop through each byte in the array
            foreach (byte data in comByte)
                //convert the byte to a string and add to the stringbuilder
                builder.Append(Convert.ToString(data, 16).PadLeft(2, '0').PadRight(3, ' '));
            //return the converted value
            return builder.ToString().ToUpper();
        }
        #endregion

        #region DisplayData
        /// <summary>
        /// method to display the data to & from the port
        /// on the screen
        /// </summary>
        /// <param name="type">MessageType of the message</param>
        /// <param name="msg">Message to display</param>
        [STAThread]
        private void DisplayData(MessageType type, string msg)
        {
            _displayWindow.Invoke(new EventHandler(delegate
        {
            _displayWindow.SelectedText = string.Empty;
            _displayWindow.SelectionFont = new Font(_displayWindow.SelectionFont, FontStyle.Bold);
            _displayWindow.SelectionColor = MessageColor[(int)type];
            _displayWindow.AppendText(msg);
            _displayWindow.ScrollToCaret();
        }));
        }
        #endregion

        #region OpenPort
        public bool OpenPort()
        {
            try
            {
                //first check if the port is already open
                //if its open then close it
                if (comPort.IsOpen == true) comPort.Close();

                //set the properties of our SerialPort Object
                comPort.BaudRate = int.Parse(_baudRate);    //BaudRate
                comPort.DataBits = int.Parse(_dataBits);    //DataBits
                comPort.StopBits = (StopBits)Enum.Parse(typeof(StopBits), _stopBits);    //StopBits
                comPort.Parity = (Parity)Enum.Parse(typeof(Parity), _parity);    //Parity
                comPort.PortName = _portName;   //PortName
                //now open the port
                comPort.Open();
                //comPort.WriteLine("$");
                //display message
                DisplayData(MessageType.Warning, "Serial Port opened at " + DateTime.Now + "\n");
                //return true
                return true;
            }
            catch (Exception ex)
            {
                DisplayData(MessageType.Error, ex.Message);
                return false;
            }
        }
        #endregion

        #region SetParityValues
        public void SetParityValues(object obj)
        {
            foreach (string str in Enum.GetNames(typeof(Parity)))
            {
                ((ComboBox)obj).Items.Add(str);
            }
        }
        #endregion

        #region SetStopBitValues
        public void SetStopBitValues(object obj)
        {
            foreach (string str in Enum.GetNames(typeof(StopBits)))
            {
                ((ComboBox)obj).Items.Add(str);
            }
        }
        #endregion

        #region SetPortNameValues
        public void SetPortNameValues(object obj)
        {

            foreach (string str in SerialPort.GetPortNames())
            {
                ((ComboBox)obj).Items.Add(str.Trim());
            }
        }
        #endregion

        #region comPort_DataReceived
        /// <summary>
        /// method that will be called when theres data waiting in the buffer
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void comPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                if (comPort == null || !comPort.IsOpen)
                    return;

                switch (CurrentTransmissionType)
                {
                    case TransmissionType.Text:
                        {
                            string chunk = comPort.ReadExisting();
                            if (!string.IsNullOrEmpty(chunk))
                            {
                                // 1) Affiche tel quel dans la console
                                DisplayData(MessageType.Incoming, chunk);

                                // 2) Notifie l'app, même sans fin de ligne
                                //    - on normalise CR->LF
                                //    - on découpe par LF
                                //    - si aucune "ligne" non vide n'est trouvée, on envoie le chunk trim brut
                                string norm = chunk.Replace('\r', '\n');
                                var parts = norm.Split('\n');
                                bool any = false;
                                foreach (var part in parts)
                                {
                                    var line = part?.Trim();
                                    if (!string.IsNullOrEmpty(line))
                                    {
                                        any = true;
                                        try { LineReceived?.Invoke(line); } catch { }
                                    }
                                }
                                if (!any)
                                {
                                    var line = chunk.Trim();
                                    if (line.Length > 0)
                                        try { LineReceived?.Invoke(line); } catch { }
                                }
                            }
                            break;
                        }

                    case TransmissionType.Hex:
                        {
                            int bytes = comPort.BytesToRead;
                            if (bytes > 0)
                            {
                                byte[] buf = new byte[bytes];
                                comPort.Read(buf, 0, bytes);
                                DisplayData(MessageType.Incoming, ByteToHex(buf) + "\n");

                                // on envoie la “ligne” hex compactée pour que le parseur puisse, si besoin
                                var hexLine = ByteToHex(buf).Trim();
                                if (hexLine.Length > 0)
                                    try { LineReceived?.Invoke(hexLine); } catch { }
                            }
                            break;
                        }
                    default:
                        {
                            string chunk = comPort.ReadExisting();
                            if (!string.IsNullOrEmpty(chunk))
                            {
                                DisplayData(MessageType.Incoming, chunk);
                                string norm = chunk.Replace('\r', '\n');
                                foreach (var part in norm.Split('\n'))
                                {
                                    var line = part?.Trim();
                                    if (!string.IsNullOrEmpty(line))
                                        try { LineReceived?.Invoke(line); } catch { }
                                }
                            }
                            break;
                        }

                }
            }
            catch (InvalidOperationException) { }
            catch (System.IO.IOException) { }
            catch { }
        }
        #endregion  // ferme la région comPort_DataReceived

        // Surcharge pour n'afficher que les n octets lus (utilisée plus haut en Hex)
        private string ByteToHex(byte[] data, int count)
        {
            var sb = new StringBuilder(count * 3);
            for (int i = 0; i < count; i++)
                sb.Append(data[i].ToString("X2")).Append(' ');
            return sb.ToString();
        }

        public void closePort()
        {
            try
            {
                if (comPort.IsOpen == true) comPort.Close();
                DisplayData(MessageType.Warning, "Serial Port closed at " + DateTime.Now + "\n");
            }
            catch (Exception ex)
            {
            }
        }
    }

}

