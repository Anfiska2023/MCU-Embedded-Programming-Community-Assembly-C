/*
 * msireefp.h
 *
 *  Created on: Oct 6, 2025
 *      Author: Anisov Andre
 */

#ifndef INC_MSIREEFP_H_
#define INC_MSIREEFP_H_

#ifdef __cplusplus
extern "C" {
#endif

/* ===== Includes standard & HAL ===== */
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include "stm32l0xx_hal.h"   // Types et HAL STM32L0
#include "main.h"            // Définitions projet (pins générées, etc.)
#include "gpio.h"            // Ports/broches
#include "usart.h"           // huart1
#include "dac.h"             // hdac
#include "rtc.h"             // hrtc

/* ===== Handles externes générés par CubeMX ===== */
extern UART_HandleTypeDef huart1;   // USART1
extern DAC_HandleTypeDef  hdac;     // DAC1 (PA4)
extern RTC_HandleTypeDef  hrtc;     // RTC (LSE)

/* ===== Paramètres protocole (tailles) ===== */
#ifndef LINE_MAX
#define LINE_MAX        128u   /* taille max d’une trame <...> sans chevrons */
#endif
#ifndef MAX_FIELDS
#define MAX_FIELDS      10u    /* nb max de champs séparés par des virgules */
#endif
#ifndef MAX_FIELD_LEN
#define MAX_FIELD_LEN   32u    /* longueur max de chaque champ */
#endif

/* 0,5 s pour la tâche périodique SysTick (LED) */
#ifndef HalfSec
#define HalfSec         500u
#endif

/* ===== Data EEPROM STM32L0 ===== */
#ifndef DATA_EEPROM_BASE
#define DATA_EEPROM_BASE   ((uint32_t)0x08080000U) /* Base DATA EEPROM L0 */
#endif

/* Offsets (demi-mots 16b) — cohérents avec msireefp.c */
#define OFF_MAGIC          0x0000u
#define OFF_ID_LO          0x0002u   /* ID 32b LOW  */
#define OFF_ID_HI          0x0004u   /* ID 32b HIGH */
#define OFF_HOLD_MINUTES   0x0006u   /* durée hold en minutes (1..120) */
#define OFF_DIM_MIN_PCT    0x0008u   /* dim mini en % (10..100) */

#define MAGIC_VALUE        0xBEEF

// Nouveau paramètre EEPROM
#define OFF_MOTION_MODE   0x000Au   // 16 bits, 0=NORM, 1=INV
#define OFF_HI_REF_PCT    0x000Cu   // 1..100 : "High" de référence (nouveau 100%)


/* ===== Bornes applicatives ===== */
#define HOLD_MIN_VAL       1u
#define HOLD_MAX_VAL       120u
#define DIM_MIN_VAL_PCT    10u
#define DIM_MAX_VAL_PCT    100u
#define HI_MIN_VAL_PCT     1u
#define HI_MAX_VAL_PCT     100u


#ifndef MINUTES
#define MINUTES(x)         ((uint32_t)(x) * 60u) /* min -> sec */
#endif

/* Variables runtime exposées (optionnel) */
extern volatile uint16_t g_hold_minutes; /* MM minutes (EEPROM) */
extern volatile uint16_t g_dim_min_pct;  /* % mini (EEPROM) */
extern volatile uint8_t  g_hi_ref_pct;   /* % HI référence (EEPROM) */


/* ===== Broche capteur mouvement (adapter si besoin) =====
   Ici : PB1 en EXTI Falling (config CubeMX) */
#define MOTION_GPIO_Port   GPIOB
#define MOTION_Pin         GPIO_PIN_1

/* ===== Prototypes publics ===== */
/* SysTick & tâche 0,5 s LED */
void HAL_IncTick(void);     /* surcharge HAL (tick 1 ms) */
void halfSecondTask(void);  /* LED ST */
void pinToggle(int pin);    /* helper toggle */

/* Temporisation via RTC WakeUp (secondes, 1 Hz) */
void StartHoldoff_s(uint32_t seconds);

/* Logique motion inversée : appel dans HAL_GPIO_EXTI_Callback */
void MotionDetected_StartHold(void);

/* DAC : appliquer un pourcentage (0..100) */
void ApplyBrightnessPercent(uint16_t pct);

/* Test DAC 25→50→75→100 % (non bloquant) */
void DAC_TestStart(uint32_t period_ms);
void DAC_TestService(void);

/* UART1 : envoi + parsing protocole <,CMD,...,> */
void SendDataCOM1(char *buffer);
void HAL_Comm_UART_IRQ(UART_HandleTypeDef *huart);
void ReceiveData(const char *buffer);

/* Réglages EEPROM */
void  Settings_LoadFromEEPROM(void);
bool  Settings_SaveHoldMinutes(uint16_t minutes);  /* 1..120 */
bool  Settings_SaveDimMinPct(uint16_t pct);        /* 10..100 */
bool Settings_SaveMotionMode(uint16_t inv01);

/* Accès DATA EEPROM 16 bits (L0) */
bool     EEP_Write16(uint32_t off, uint16_t v);
uint16_t EEP_Read16 (uint32_t off);

/* ID 32 bits en 2×16b + MAGIC */
bool ID_Save(uint32_t id);
bool ID_Load(uint32_t *out_id);
bool ID_Reset(void);

/* Aide / statut compact (convenience) */
void SendHelp(void);
void SendPrintCfgLine(void);

void MotionMessage_Service(void);

bool  Settings_SaveHiRefPct(uint16_t pct);     /* 1..100 */

void  ApplyHigh(void);     /* applique HI (absolu) */
void  ApplyLow(void);      /* applique (HI * Low)/100 */
void  ApplyLogicalPercent(uint16_t p); /* applique p% *HI (ex. DAC) */


#ifdef __cplusplus
}
#endif

#endif /* INC_MSIREEFP_H_ */
