/*
 * msireefp.c
 *
 *  Created on: Oct 6, 2025
 *      Author: Anisov Andre
 */

/* msireefp.c — DAC + motion inversée + EEPROM L0 + UART
 * Carte STM32L0 (p.ex. STM32L062). Commentaires FR.
 * This programm use only for motion sensor - he is programmed by USART  dimming 10-100%, time 1 min to 2 hours
 */

#include "msireefp.h"
#include "main.h"
#include "stm32l0xx_hal.h"
#include "gpio.h"
#include "usart.h"
#include "dac.h"
#include "rtc.h"
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>

/* ===== Défauts de secours (si le .h n’est pas inclus avant) ===== */
#ifndef LINE_MAX
#define LINE_MAX        128u
#endif
#ifndef MAX_FIELDS
#define MAX_FIELDS      10u
#endif
#ifndef MAX_FIELD_LEN
#define MAX_FIELD_LEN   32u
#endif
#ifndef HalfSec
#define HalfSec         500u
#endif
#ifndef DATA_EEPROM_BASE
#define DATA_EEPROM_BASE ((uint32_t)0x08080000U)
#endif
#ifndef HalfSec
#define HalfSec         500u
#endif
/* ===== Vérif offsets EEPROM attendus (sécurité compile-time) ===== */
#if (OFF_MAGIC!=0x0000u) || (OFF_ID_LO!=0x0002u) || (OFF_ID_HI!=0x0004u) || \
    (OFF_HOLD_MINUTES!=0x0006u) || (OFF_DIM_MIN_PCT!=0x0008u)
#error "Offsets EEPROM inattendus — vérifie msireefp.h"
#endif

/* ===== Anti-rebond / anti faux-triggers EXTI ===== */
static volatile uint32_t s_ignore_exti_until_ms = 0;   // ignore EXTI jusqu’à date (après SET*)
static volatile uint32_t s_last_exti_ms         = 0;   // dernier front validé (ms)
static const    uint32_t EXTI_DEBOUNCE_MS       = 50;  // anti-rebond 50 ms
static const    uint32_t EXTI_GUARD_AFTER_CMD_MS= 150; // garde 150 ms après commandes SET*

/* ===== Handles externes générés par CubeMX ===== */
extern UART_HandleTypeDef huart1;
extern DAC_HandleTypeDef  hdac;
extern RTC_HandleTypeDef  hrtc;

/* ===== Variables runtime ===== */
volatile uint16_t g_hold_minutes = 15;    // durée (1..120) chargée au boot depuis EEPROM
volatile uint16_t g_dim_min_pct  = 20;    // % mini (10..100)
volatile uint8_t  g_hi_ref_pct  = 100;  // HI programmable (EEPROM) 1..100
static uint32_t s_period = 300;           // période entre pas (ms)

/* État “test DAC par pas” (25/50/75/100 %) */
static const uint8_t kStepsPct[] = {25, 50, 75, 100};
static uint8_t  s_active = 0;             // 1 = test en cours
static uint8_t  s_idx    = 0;             // index du pas courant
static uint32_t s_nextms = 0;             // prochaine échéance en ms
//static uint32_t s_period = 300;           // période entre pas (ms)

/* Minuteur “hold” géré à 1 Hz par le WakeUp RTC */
static volatile uint32_t s_hold_seconds_left = 0;  // secondes restantes
static volatile uint8_t  s_timer_active      = 0;  // 1 si actif
/* ===== Heartbeat (LED système) dynamique =====
+   - hb_enabled: ON/OFF global
+   - hb_fast_mode: si 1 → période rapide quand idle (pas de mouvement)
+   - hb_base_ms: période nominale (ex. 500 ms)
+   - hb_fast_ms: période idle (ex. 200 ms)
+   - hb_next_ms: prochaine échéance (en ms absolu)
+   Convention:
+     * "mouvement" = front EXTI → on force période base (retour 500 ms)
+     * "idle" = après fin du hold (timer RTC à 0) → on passe en rapide si activé
+*/
static volatile uint8_t  hb_enabled    = 1;
static volatile uint8_t  hb_fast_mode  = 1;
static volatile uint32_t hb_base_ms    = 500;
static volatile uint32_t hb_fast_ms    = 200;
static volatile uint32_t hb_next_ms    = 0;
// Fenêtres (runtime, non persistantes)
static volatile uint32_t MOTION_REFRACT_MS = 600;  // blocage re-détection EXTI
static volatile uint32_t MSMSG_WINDOW_MS   = 600;  // intervalle min entre messages UART
static volatile uint8_t  sensormess        = 0;    // 0=OFF, 1=ON (messages motion)

// 0 = mode NORMAL (mouvement -> 100%, repos -> min après délai)
// 1 = mode INVERSE (mouvement -> min, repos -> 100%)  [COMPORTEMENT ACTUEL]
static volatile uint8_t motion_invert = 1;

static volatile uint8_t ms_msg_pending = 0;



static inline uint32_t HB_CurrentPeriod(void)
{
   // Idle si aucun timer actif → rapide si hb_fast_mode, sinon base
    if (!s_timer_active) return hb_fast_mode ? hb_fast_ms : hb_base_ms;
    // Pendant/juste après mouvement (timer actif) → base
    return hb_base_ms;
}

static inline void HB_OnMotion(void)
{
    // Mouvement → repasse à la période de base dès maintenant
    hb_next_ms = HAL_GetTick() + hb_base_ms;
}

static inline void HB_OnIdle(void)
{
    // Retour à l'état idle → programme la prochaine échéance selon mode
   hb_next_ms = HAL_GetTick() + HB_CurrentPeriod();
}


/* ===== SYSTICK — surcharge (1 ms) : clignote LED toutes ~0,5 s ===== */
void HAL_IncTick(void)
{
    uwTick += uwTickFreq;                 // tick HAL
    // ===== Heartbeat non bloquant et désactivable =====
        if (!hb_enabled) return;              // <---- empêche tout clignotement si HB=0
        uint32_t now = uwTick;
         // Initialisation paresseuse de l’échéance
       if (hb_next_ms == 0) hb_next_ms = now + HB_CurrentPeriod();
       if ((int32_t)(now - hb_next_ms) >= 0)
       {
           pinToggle(ST_Pin);
           hb_next_ms = now + HB_CurrentPeriod();
       }
}

/* ===== EXTI capteur mouvement (PB1, falling) ===== */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if (GPIO_Pin != MOTION_Pin) return;

    uint32_t now = HAL_GetTick();
    if ((int32_t)(now - s_ignore_exti_until_ms) < 0) return;
    if ((now - s_last_exti_ms) < EXTI_DEBOUNCE_MS)   return;

    // fenêtre réfractaire (si tu l’utilises)
    static uint32_t s_last_valid_motion_ms = 0;
    if ((now - s_last_valid_motion_ms) < MOTION_REFRACT_MS) return;
    s_last_valid_motion_ms = now;

    s_last_exti_ms = now;

    MotionDetected_StartHold();
    HB_OnMotion();

    // anti-flood UART et marquage d’un message à envoyer (hors IRQ)
    if (sensormess) {
        static uint32_t last_msg_ms = 0;
        if ((now - last_msg_ms) >= MSMSG_WINDOW_MS) {
            ms_msg_pending = 1;          // <-- juste un flag
            last_msg_ms    = now;
        }
    }
}

void MotionMessage_Service(void)
{
    if (ms_msg_pending) {
        ms_msg_pending = 0;
        SendDataCOM1("EXTI: Motion detected\r\n");
    }
}


/* ===== DAC : % (0..100) -> valeur 12 bits et start ===== */
static inline uint32_t pct_to_dac12(uint16_t pct)
{
    if (pct > 100u) pct = 100u;
    return (uint32_t)((pct * 4095u + 50u) / 100u); // arrondi correct
}
void ApplyBrightnessPercent(uint16_t pct)
{
    if (pct > 100u) pct = 100u;
    HAL_DAC_SetValue(&hdac, DAC_CHANNEL_1, DAC_ALIGN_12B_R, pct_to_dac12(pct));
    HAL_DAC_Start(&hdac, DAC_CHANNEL_1);
}

/* ===== Mise à l’échelle par HI ===== */
static inline uint16_t ScaleByHi(uint16_t pct_logic)    // 0..100 logique → absolu
{
    if (pct_logic > 100u) pct_logic = 100u;
    return (uint16_t)((g_hi_ref_pct * pct_logic + 50u) / 100u);
}

/* Applique un pourcentage LOGIQUE (échelle HI) */
void ApplyLogicalPercent(uint16_t pct_logic)
{
    ApplyBrightnessPercent(ScaleByHi(pct_logic));
}

/* High effectif = HI% absolu */
void ApplyHigh(void)
{
    ApplyBrightnessPercent(g_hi_ref_pct);
}

/* Low effectif = (HI * LOW)/100 */
void ApplyLow(void)
{
    ApplyBrightnessPercent(ScaleByHi(g_dim_min_pct));
}


/* ===== Test DAC 25→50→75→100 % (non bloquant) ===== */
void DAC_TestStart(uint32_t period_ms)
{
    s_active = 1u;
    s_idx    = 0u;
    s_period = (period_ms == 0u) ? 1u : period_ms;
    s_nextms = HAL_GetTick();            // départ immédiat
}
void DAC_TestService(void)
{
    if (!s_active) return;
    if ((int32_t)(HAL_GetTick() - s_nextms) >= 0) {
    	ApplyLogicalPercent(kStepsPct[s_idx]);   // échelle HI
        s_idx++;
        if (s_idx >= (sizeof(kStepsPct) / sizeof(kStepsPct[0]))) {
            s_active = 0u;                            // fin du test
        } else {
            s_nextms = HAL_GetTick() + s_period;      // programme l’échéance suivante
        }
    }
}

/* ===== RTC WakeUp : programme un one-shot en secondes (1 Hz) =====
   Stratégie : on arme le WUT à 1 seconde périodique et on décrémente
   s_hold_seconds_left à chaque IRQ jusqu’à 0. */
void StartHoldoff_s(uint32_t seconds)
{
    if (seconds == 0u) seconds = 1u;

    s_hold_seconds_left = seconds;                    // charge le compteur
    s_timer_active      = 1u;                         // marque actif

    HAL_RTCEx_DeactivateWakeUpTimer(&hrtc);           // stop si déjà armé
    /* WUT = 1 Hz (prédiviseurs configurés par MX_RTC_Init) */
    __HAL_RTC_WAKEUPTIMER_CLEAR_FLAG(&hrtc, RTC_FLAG_WUTF); // clear HORS IRQ
    HAL_RTCEx_SetWakeUpTimer_IT(&hrtc, 0, RTC_WAKEUPCLOCK_CK_SPRE_16BITS);
}

/* ===== Logique “motion inversée” validée en test =====
   • Détection de mouvement  → applique immédiatement g_dim_min_pct (LOW)
   • Après MM minutes        → remonte à 100 % (HIGH) */
void MotionDetected_StartHold(void)
{
	if (motion_invert) {
	    ApplyLow();      // présence -> min effectif (HI * low /100)
	} else {
	    ApplyHigh();     // présence -> HI%
	}


    // Ne (ré)arme le RTC que si aucun hold n'est déjà actif
    if (!s_timer_active) {
        StartHoldoff_s(MINUTES(g_hold_minutes));
    }

    HB_OnMotion();  // heartbeat -> période base
}



/* ===== Callback WakeUp RTC (1 Hz) ===== */
void HAL_RTCEx_WakeUpTimerEventCallback(RTC_HandleTypeDef *hrtc_cb)
{
    if (hrtc_cb->Instance != RTC) return;

    if (s_timer_active && s_hold_seconds_left > 0) {
        if (--s_hold_seconds_left == 0) {
        	if (motion_invert) ApplyHigh(); else ApplyLow();
            HAL_RTCEx_DeactivateWakeUpTimer(hrtc_cb);   // désarme le WUT
            s_timer_active = 0u;
            HB_OnIdle();
        }
    }
}

bool Settings_SaveHiRefPct(uint16_t pct)
{
    if (pct < HI_MIN_VAL_PCT || pct > HI_MAX_VAL_PCT) return false;
    g_hi_ref_pct = (uint8_t)pct;
    return EEP_Write16(OFF_HI_REF_PCT, (uint16_t)g_hi_ref_pct);
}


/* ===== EEPROM : charge / sauve les paramètres (MM et %) ===== */
void Settings_LoadFromEEPROM(void)
{
    uint16_t v;

    v = EEP_Read16(OFF_HOLD_MINUTES);
    if (v >= HOLD_MIN_VAL && v <= HOLD_MAX_VAL) g_hold_minutes = v;

    v = EEP_Read16(OFF_DIM_MIN_PCT);
    if (v >= DIM_MIN_VAL_PCT && v <= DIM_MAX_VAL_PCT) g_dim_min_pct = v;
    // ---- Nouveau : charger HI reference (1..100), défaut = 100
    v = EEP_Read16(OFF_HI_REF_PCT);
    if (v >= HI_MIN_VAL_PCT && v <= HI_MAX_VAL_PCT) g_hi_ref_pct = (uint8_t)v;
    else                                            g_hi_ref_pct = 100u;

    // ---- Nouveau : charger motion_invert (0/1), sinon défaut = 1 (INV)
        v = EEP_Read16(OFF_MOTION_MODE);
        if (v <= 1u) motion_invert = (uint8_t)v;
        else         motion_invert = 1u;   // backward compat : défaut = INVERSE
}
bool Settings_SaveHoldMinutes(uint16_t minutes)
{
    if (minutes < HOLD_MIN_VAL || minutes > HOLD_MAX_VAL) return false;
    g_hold_minutes = minutes;
    return EEP_Write16(OFF_HOLD_MINUTES, minutes);
}
bool Settings_SaveDimMinPct(uint16_t pct)
{
    if (pct < DIM_MIN_VAL_PCT || pct > DIM_MAX_VAL_PCT) return false;
    g_dim_min_pct = pct;
    return EEP_Write16(OFF_DIM_MIN_PCT, pct);
}

bool Settings_SaveMotionMode(uint16_t inv01)
{
    if (inv01 > 1u) return false;
    return EEP_Write16(OFF_MOTION_MODE, (uint16_t)inv01);
}


/* ===== Accès DATA EEPROM (STM32L0) 16 bits ===== */
bool EEP_Write16(uint32_t off, uint16_t v)
{
    HAL_FLASHEx_DATAEEPROM_Unlock();
    HAL_StatusTypeDef st = HAL_FLASHEx_DATAEEPROM_Program(
        FLASH_TYPEPROGRAMDATA_HALFWORD,             // écriture demi-mot 16b
        DATA_EEPROM_BASE + off, v
    );
    HAL_FLASHEx_DATAEEPROM_Lock();
    return (st == HAL_OK);
}
uint16_t EEP_Read16(uint32_t off)
{
    return *(volatile uint16_t*)(DATA_EEPROM_BASE + off);
}

/* ===== ID 32 bits en 2×16b + MAGIC ===== */
bool ID_Save(uint32_t id)
{
    uint16_t lo = (uint16_t)(id & 0xFFFFu);
    uint16_t hi = (uint16_t)(id >> 16);
    if (!EEP_Write16(OFF_ID_LO, lo))  return false;
    if (!EEP_Write16(OFF_ID_HI, hi))  return false;
    if (!EEP_Write16(OFF_MAGIC, MAGIC_VALUE)) return false;
    return true;
}
bool ID_Load(uint32_t *out_id)
{
    if (EEP_Read16(OFF_MAGIC) != MAGIC_VALUE) return false;
    uint16_t lo = EEP_Read16(OFF_ID_LO);
    uint16_t hi = EEP_Read16(OFF_ID_HI);
    *out_id = ((uint32_t)hi << 16) | lo;
    return true;
}
bool ID_Reset(void)
{
    return EEP_Write16(OFF_MAGIC, 0x0000u);           // invalide simplement MAGIC
}

/* ===== LED système (0,5 s) ===== */
void halfSecondTask(void)
{
	pinToggle(ST_Pin);
}
void pinToggle(int pin)
{
    if (pin == ST_Pin) HAL_GPIO_TogglePin(ST_GPIO_Port, pin);
}

/* ===== UART1 TX : envoi d’une chaîne ===== */
void SendDataCOM1(char *buffer)
{
    HAL_UART_Transmit(&huart1, (uint8_t*)buffer, strlen(buffer), 100u);
}

/* ===== Aide (liste des commandes) ===== */
void SendHelp(void)
{
    static const char *lines[] = {
        "=== HELP (MSIREE-L0) ===\r\n",
        "<,INFO,>\r\n",
        "<,SETID,NNNNNNNN,>  | <,GETID,> | <,EERESET,>\r\n",
        "<,SETDUR,MM,> (1..120) | <,GETDUR,>\r\n",
        "<,SETDIM,PP,> (10..100) | <,GETDIM,>\r\n",
        "<,TRIG,>  (presence -> dim mini puis timer)\r\n",
        "<,TRIGH,> (force 100% & stop timer)\r\n",
        "<,TRIGL,> (force min sans timer)\r\n",
        "<,DAC,PP,> | <,DACTEST,TT,>\r\n",
        "<,GETREMAIN,>  (secondes restantes)\r\n",
        "<,PRINTCFGLN,>\r\n",
		"<,HB,0|1,>        (heartbeat OFF/ON)\r\n",
		"<,HBF,0|1,>       (FAST mode en idle OFF/ON)\r\n",
		"<,HBPER,NNN,>     (periode base ms, ex 500)\r\n",
		"<,HBFAST,NNN,>    (periode rapide ms, ex 200)\r\n",
		"<,GETHB,>         (statut heartbeat)\r\n",
		"<,MOTION,MODE,INV|NORM[,SAVE],>\r\n",
		"<,GETMOTION,>\r\n",
		"<,MSMSG,1|0,>  (message UART sur mouvement ON/OFF)\r\n",
		"<,MSMSG,WIN,NNN,>  (intervalle minimal entre messages, ms)\r\n",
		"<,MOTION,REFRACT,NNN,>  (fenetre refractaire EXTI, ms)\r\n",
		"<,SETHI,PP,> (1..100) | <,GETHI,>\r\n",
        "\r\n"
    };
    for (size_t i = 0; i < sizeof(lines)/sizeof(lines[0]); ++i) {
        SendDataCOM1((char*)lines[i]);
    }
}

/* ===== IRQ RX USART1 : assemble < ... > puis appelle ReceiveData() ===== */
void HAL_Comm_UART_IRQ(UART_HandleTypeDef *huart)
{
    static uint8_t rx_buffer[LINE_MAX];
    static int     rx_index = 0;
    uint32_t isr = huart->Instance->ISR;

    if ((isr & UART_FLAG_RXNE) || (isr & UART_FLAG_ORE)) {
        uint16_t d = (uint16_t)(huart->Instance->RDR & 0x01FFu); // lire RDR efface RXNE

        if (d == '<') {
            rx_index = 0;
        } else if (d == '>') {
            rx_buffer[rx_index] = '\0';
            ReceiveData((char*)rx_buffer);
            rx_index = 0;
        } else {
            if (rx_index < (int)LINE_MAX - 1) rx_buffer[rx_index++] = (uint8_t)d;
            else rx_index = 0; // overflow → reset
        }
    }

    /* Nettoyage erreurs éventuelles */
    if (isr & UART_FLAG_ORE) __HAL_UART_CLEAR_FLAG(huart, UART_FLAG_ORE);
    if (isr & UART_FLAG_NE)  __HAL_UART_CLEAR_NEFLAG(huart);
    if (isr & UART_FLAG_FE)  __HAL_UART_CLEAR_FEFLAG(huart);
    if (isr & UART_FLAG_PE)  __HAL_UART_CLEAR_PEFLAG(huart);
}

/* ===== Ligne statut compacte (ID, DUR, DIM, RESTANT, TIMER) ===== */
void SendPrintCfgLine(void)
{
    char buf[96];
    uint32_t id = 0;
    uint8_t have_id = ID_Load(&id) ? 1 : 0;

    snprintf(buf, sizeof(buf),
             "CFG:ID=%s%lu,DUR=%u,DIM=%u,HI=%u,REMAIN=%lu,TIMER=%s\r\n",
             have_id ? "" : "NA:",
             have_id ? (unsigned long)id : 0ul,
             (unsigned)g_hold_minutes,
             (unsigned)g_dim_min_pct,
             (unsigned)g_hi_ref_pct,
             (unsigned long)(s_timer_active ? s_hold_seconds_left : 0ul),
             s_timer_active ? "ON" : "OFF");
    SendDataCOM1(buf);
}

/* ===== Parsing des commandes <,CMD,...,> ===== */
void ReceiveData(const char *buffer)
{
    char    data[MAX_FIELDS][MAX_FIELD_LEN] = {{0}};
    uint8_t pos = 0u, count = 0u;
    char    temp[64];

    /* Découpage par virgules */
    for (int i = 0; i < (int)strlen(buffer); i++) {
        if (buffer[i] == ',') {
            data[pos][count] = '\0'; pos++; count = 0;
            if (pos >= MAX_FIELDS) break;
        } else if (count < (MAX_FIELD_LEN - 1u)) {
            data[pos][count++] = buffer[i];
        }
    }
    data[pos][count] = '\0';

    /* --- Commandes --- */
    if (strcmp(data[1], "INFO") == 0) {
        SendDataCOM1("INFO: STM32L0 Ver1.0\r\n");
    }
    else if (strcmp(data[1], "SETID") == 0) {
        uint32_t id = (uint32_t)strtoul(data[2], NULL, 10);
        if (ID_Save(id)) sprintf(temp, "ID programme: %lu\r\n", (unsigned long)id);
        else             sprintf(temp, "Erreur EEPROM\r\n");
        SendDataCOM1(temp);
    }
    else if (strcmp(data[1], "GETID") == 0) {
        uint32_t id;
        if (ID_Load(&id)) sprintf(temp, "Programmed ID is %lu\r\n", (unsigned long)id);
        else              sprintf(temp, "ID not set\r\n");
        SendDataCOM1(temp);
    }
    else if (strcmp(data[1], "EERESET") == 0) {
        if (ID_Reset()) SendDataCOM1("OK: factory reset\r\n");
        else            SendDataCOM1("ERR: eeprom\r\n");
    }
    else if (strcmp(data[1], "SETDUR") == 0) {       // minutes 1..120
        uint32_t mm = (uint32_t)strtoul(data[2], NULL, 10);
        if (Settings_SaveHoldMinutes((uint16_t)mm))
            sprintf(temp, "OK DUR=%lu min\r\n", (unsigned long)mm);
        else
            sprintf(temp, "ERR: DUR range 1..120 min\r\n");
        SendDataCOM1(temp);
        s_ignore_exti_until_ms = HAL_GetTick() + EXTI_GUARD_AFTER_CMD_MS; // garde anti faux-front
    }
    else if (strcmp(data[1], "GETDUR") == 0) {
        sprintf(temp, "DUR=%u min\r\n", (unsigned)g_hold_minutes);
        SendDataCOM1(temp);
    }
    else if (strcmp(data[1], "SETHI") == 0) {      // 1..100
        uint32_t pp = (uint32_t)strtoul(data[2], NULL, 10);
        if (Settings_SaveHiRefPct((uint16_t)pp))
            sprintf(temp, "OK HI=%lu %%\r\n", (unsigned long)pp);
        else
            sprintf(temp, "ERR: HI range 1..100 %%\r\n");
        SendDataCOM1(temp);
        s_ignore_exti_until_ms = HAL_GetTick() + EXTI_GUARD_AFTER_CMD_MS; // garde anti faux-front
    }
    else if (strcmp(data[1], "GETHI") == 0) {
        sprintf(temp, "HI=%u %%\r\n", (unsigned)g_hi_ref_pct);
        SendDataCOM1(temp);
    }
    else if (strcmp(data[1], "SETDIM") == 0) {       // % 10..100
        uint32_t pp = (uint32_t)strtoul(data[2], NULL, 10);
        if (Settings_SaveDimMinPct((uint16_t)pp))
            sprintf(temp, "OK DIM=%lu %%\r\n", (unsigned long)pp);
        else
            sprintf(temp, "ERR: DIM range 10..100 %%\r\n");
        SendDataCOM1(temp);

        if (data[3][0] && strcmp(data[3], "NOW") == 0)  // option: appliquer tout de suite
        	ApplyLow();

        s_ignore_exti_until_ms = HAL_GetTick() + EXTI_GUARD_AFTER_CMD_MS;
    }
    else if (strcmp(data[1], "GETDIM") == 0) {
        sprintf(temp, "DIM=%u %%\r\n", (unsigned)g_dim_min_pct);
        SendDataCOM1(temp);
    }
    else if (strcmp(data[1], "DACTEST") == 0) {      // ms optionnel
        uint32_t period = 300u;
        if (data[2][0] != '\0') period = strtoul(data[2], NULL, 10);
        DAC_TestStart(period);
        SendDataCOM1("OK: DACTEST started\r\n");
    }
    else if (strcmp(data[1], "DAC") == 0) {          // % 0..100
        uint32_t pct = strtoul(data[2], NULL, 10);
        if (pct <= 100u) {
        	ApplyLogicalPercent((uint16_t)pct);
        	sprintf(temp, "OK: DAC_LOGIC=%lu%% (HI=%u%%)\r\n", (unsigned long)pct, (unsigned)g_hi_ref_pct);
        } else {
            sprintf(temp, "ERR: range 0..100%%\r\n");
        }
        SendDataCOM1(temp);
    }
    else if (strcmp(data[1], "TRIG") == 0) {         // simule un mouvement
        MotionDetected_StartHold();
        SendDataCOM1("OK: TRIG\r\n");
    }
    else if (strcmp(data[1], "TRIGH") == 0) {        // force 100 % (annule timer)
        HAL_RTCEx_DeactivateWakeUpTimer(&hrtc);
        s_timer_active = 0u;
        ApplyHigh();
        SendDataCOM1("OK: TRIGH\r\n");
        HB_OnIdle();
    }
    else if (strcmp(data[1], "TRIGL") == 0) {        // force mini sans timer
        HAL_RTCEx_DeactivateWakeUpTimer(&hrtc);
        s_timer_active = 0u;
        ApplyLow();
        SendDataCOM1("OK: TRIGL\r\n");
        HB_OnMotion(); // rester en base car "présence"
    }
    /* ===== Heartbeat commands ===== */
    else if (strcmp(data[1], "HB") == 0)
    {           // 0/1
      if (data[2][0]=='0')
      {
    	  hb_enabled = 0;
      }
      else if (data[2][0]=='1')
      {
    	hb_enabled = 1; hb_next_ms = 0;
      }
           SendDataCOM1(hb_enabled ? "HB=ON\r\n" : "HB=OFF\r\n");
    }
    else if (strcmp(data[1], "HBF") == 0)
    {          // fast mode 0/1
           if (data[2][0]=='0') hb_fast_mode = 0;
           else if (data[2][0]=='1') hb_fast_mode = 1;
            HB_OnIdle(); // recalcule l’échéance si on est idle
            SendDataCOM1(hb_fast_mode ? "HBF=ON\r\n" : "HBF=OFF\r\n");
    }
    else if (strcmp(data[1], "HBPER") == 0)
    {        // base ms
            uint32_t v = (uint32_t)strtoul(data[2], NULL, 10);
         if (v>=50 && v<=5000)
         {
        	 hb_base_ms = v; HB_OnMotion(); sprintf(temp,"HBPER=%lu\r\n",(unsigned long)v);
         }
            else
            {
    	     sprintf(temp,"ERR: HBPER 50..5000 ms\r\n");
            }
            SendDataCOM1(temp);
    }
         else if (strcmp(data[1], "HBFAST") == 0) {       // fast ms
             uint32_t v = (uint32_t)strtoul(data[2], NULL, 10);
             if (v>=20 && v<=5000) { hb_fast_ms = v; HB_OnIdle(); sprintf(temp,"HBFAST=%lu\r\n",(unsigned long)v); }
             else                  { sprintf(temp,"ERR: HBFAST 20..5000 ms\r\n"); }
             SendDataCOM1(temp);
         }
         else if (strcmp(data[1], "GETHB") == 0)
         {
             snprintf(temp, sizeof(temp),
                      "HB:EN=%u,FAST=%u,PER=%lu,FASTPER=%lu,CURR=%lu\r\n",
                      (unsigned)hb_enabled, (unsigned)hb_fast_mode,
                      (unsigned long)hb_base_ms, (unsigned long)hb_fast_ms,
                      (unsigned long)HB_CurrentPeriod());
             SendDataCOM1(temp);
         }
    else if (strcmp(data[1], "GETREMAIN") == 0)
    {    // secondes restantes
        if (s_timer_active)
        {
            sprintf(temp, "REMAIN=%lu s (~%lu min)\r\n",
                    (unsigned long)s_hold_seconds_left,
                    (unsigned long)((s_hold_seconds_left + 59u)/60u));
        }
        else
        {
            sprintf(temp, "REMAIN=0 s (INACTIVE)\r\n");
        }
        SendDataCOM1(temp);
    }
    else if (strcmp(data[1], "PRINTCFGLN") == 0)
    {   // statut compact CSV
        SendPrintCfgLine();
    }
    else if (strcmp(data[1], "HELP") == 0) {
        SendHelp();
    }
    else if (strcmp(data[1], "MOTION") == 0 && strcmp(data[2], "MODE") == 0) {
        if (strcmp(data[3], "INV") == 0) {
            motion_invert = 1;
            SendDataCOM1("MOTION MODE=INV (presence->min, idle->100%)\r\n");
        } else if (strcmp(data[3], "NORM") == 0) {
            motion_invert = 0;
            SendDataCOM1("MOTION MODE=NORM (presence->100%, idle->min)\r\n");
        } else {
            SendDataCOM1("ERR: MOTION MODE (INV|NORM)\r\n");
            goto _end_motion_mode;
        }

        // Optionnel : 5e champ "SAVE" pour persister en EEPROM
        if (data[4][0] && strcmp(data[4], "SAVE") == 0) {
            if (Settings_SaveMotionMode(motion_invert)) {
                SendDataCOM1("MOTION MODE SAVED\r\n");
            } else {
                SendDataCOM1("ERR: EEPROM SAVE MOTION MODE\r\n");
            }
        }
    _end_motion_mode: ;
    }
    else if (strcmp(data[1], "GETMOTION") == 0) {
        char temp[48];
        snprintf(temp, sizeof(temp), "MOTION MODE=%s\r\n",
                 motion_invert ? "INV" : "NORM");
        SendDataCOM1(temp);
    }
    // ON/OFF message mouvement
    else if (strcmp(data[1], "MSMSG") == 0) {
        if (data[2][0]=='1') { sensormess = 1; SendDataCOM1("Motion message: ON\r\n"); }
        else if (data[2][0]=='0') { sensormess = 0; SendDataCOM1("Motion message: OFF\r\n"); }
        else if (strcmp(data[2], "WIN") == 0) {                 // fenêtre anti-flood (ms)
            if (data[3][0]) {
                uint32_t v = strtoul(data[3], NULL, 10);
                if (v >= 100 && v <= 5000) MSMSG_WINDOW_MS = v;
            }
            char t[48]; snprintf(t, sizeof(t), "MSMSG WIN=%lu ms\r\n", (unsigned long)MSMSG_WINDOW_MS);
            SendDataCOM1(t);
        } else {
            SendDataCOM1("ERR: MSMSG (0|1|WIN,NNN)\r\n");
        }
    }

    // Fenêtre réfractaire EXTI (ms)
    else if (strcmp(data[1], "MOTION") == 0 && strcmp(data[2], "REFRACT") == 0) {
        if (data[3][0]) {
            uint32_t v = strtoul(data[3], NULL, 10);
            if (v >= 100 && v <= 5000) MOTION_REFRACT_MS = v;
        }
        char t[48]; snprintf(t, sizeof(t), "MOTION REFRACT=%lu ms\r\n", (unsigned long)MOTION_REFRACT_MS);
        SendDataCOM1(t);
    }
}

/* ================= FIN msireefp.c ================= */
